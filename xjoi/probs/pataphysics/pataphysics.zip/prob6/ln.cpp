#include <bits/stdc++.h>
#define N 100005
#define int long long
using namespace std;

template <typename T>

void read(T &a)
{
	T x = 0,f = 1;
	char ch = getchar();
	while (ch < '0' || ch > '9')
	{
		if (ch == '-') f = -1;
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9')
	{
		x = (x << 1) + (x << 3) + (ch ^ 48);
		ch = getchar();
	}
	a = x * f;
}

template <typename T,typename... Args> void read(T &t,Args &... args) {read(t); read(args...); }

const int mod = 998244353;
int n,f[N],g[N << 2],r[N << 2],A[N << 2],B[N << 2],C[N << 2],lim;

int ksm(int a,int b)
{
	int res = 1;
	while (b)
	{
		if (b & 1) res = res * a % mod;
		a = a * a % mod;
		b >>= 1;
	}
	return res;
}

void getr(int lim)
{
	for (int i = 0; i < lim; i++)
		r[i] = (i & 1) * (lim >> 1) + (r[i >> 1] >> 1);
}

void ntt(int *x,int opt)
{
	for (int i = 0; i < lim; i++)
		if (r[i] < i) swap(x[i],x[r[i]]);
	for (int l = 2; l <= lim; l <<= 1)
	{
		int k = l >> 1,gn = ksm(3,(mod - 1) / l);
		for (int i = 0; i < lim; i += l)
		{
			int g = 1;
			for (int j = 0; j < k; j++)
			{
				int tmp = x[i + j + k] * g % mod;
				x[i + j + k] = (x[i + j] - tmp + mod) % mod;
				x[i + j] = (x[i + j] + tmp) % mod;
				g = g * gn % mod;
			}
		}
	}
	if (opt == -1)
	{
		reverse(x + 1,x + lim);
		int inv = ksm(lim,mod - 2);
		for (int i = 0; i < lim; i++) g[i] = g[i] * inv % mod;
	}
}

void derivation(int *f,int *g,int len)
{
	for (int i = 1; i < len; i++) g[i - 1] = i * f[i] % mod;
	g[len - 1] = 0;
}

void integration(int *f,int *g,int len)
{
	for (int i = 1; i < len; i++) g[i] = f[i - 1] * ksm(i,mod - 2) % mod;
	g[0] = 0;
}

void getinv(int *f,int *g,int len)
{
	if (len == 1)
	{
		g[0] = ksm(f[0],mod - 2);
		return ;
	}
	getinv(f,g,(len + 1) >> 1);
	lim = 1;
	while (lim <= (len << 1)) lim <<= 1;
	getr(lim);
	for (int i = 0; i < len; i++) A[i] = f[i];
	for (int i = len; i < lim; i++) A[i] = 0;
	ntt(A,1);
	ntt(g,1);
	for (int i = 0; i < lim; i++) g[i] = (2 - g[i] * A[i] % mod + mod) % mod * g[i] % mod;
	ntt(g,-1);
	for (int i = len; i < lim; i++) g[i] = 0;
}

void getln(int *f,int *g,int len)
{
	derivation(f,B,len);
	getinv(f,C,len);
	lim = 1;
	while (lim <= (len << 1)) lim <<= 1;
	getr(lim);
	ntt(B,1);
	ntt(C,1);
	for (int i = 0; i < lim; i++) C[i] = C[i] * B[i] % mod;
	ntt(C,-1);
	integration(C,g,len);
}

signed main()
{
	read(n);
	for (int i = 0; i < n; i++)
		read(f[i]);
	getln(f,g,n);
	for (int i = 0; i < n; i++)
		printf("%lld ",g[i]);
	puts("");
	return 0;
}
