#include <bits/stdc++.h>
using namespace std;

int T;
int N, M, NN;
vector<int> G[100005], H[200005];

int DFN[100005], LOW[100005], idx;
int stk[100005], len;
void Tarjan(int x) {
    DFN[x] = LOW[x] = ++idx;
    stk[++len] = x;
    for (int j = 0, l = G[x].size(); j < l; j++) {
        int v = G[x][j];
        if (!DFN[v]) {
            Tarjan(v);
            LOW[x] = min(LOW[x], LOW[v]);
            if (LOW[v] == DFN[x]) {
                NN++;
                while (stk[len + 1] != v) {
                    H[NN].push_back(stk[len]);
                    H[stk[len]].push_back(NN);
                    len--;
                }
                H[NN].push_back(x);
                H[x].push_back(NN);
            }
        } else
            LOW[x] = min(LOW[x], DFN[v]);
    }
}

int dep[200005], dis[200005], FA[200005][20];
int dfn[200005], idx0;
void DFS(int x, int f) {
    dfn[x] = ++idx0;
    dep[x] = dep[f] + 1;
    dis[x] = dis[f] + (x <= N);
    FA[x][0] = f;
    for (int k = 1; k <= 19; k++) FA[x][k] = FA[FA[x][k - 1]][k - 1];
    for (int j = 0, l = H[x].size(); j < l; j++)
        if (H[x][j] != f)
            DFS(H[x][j], x);
}

int LCA(int x, int y) {
    if (dep[x] < dep[y])
        swap(x, y);
    for (int k = 19; k >= 0; k--)
        if (dep[FA[x][k]] >= dep[y])
            x = FA[x][k];
    if (x == y)
        return x;
    for (int k = 19; k >= 0; k--)
        if (FA[x][k] != FA[y][k])
            x = FA[x][k], y = FA[y][k];
    return FA[x][0];
}
int Dis(int x, int y) { return dis[x] + dis[y] - 2 * dis[LCA(x, y)]; }

int Q, S, A[100005];
bool cmp(int a, int b) { return dfn[a] < dfn[b]; }

int main() {
    scanf("%d", &T);
    while (T--) {
        scanf("%d%d", &N, &M);
        NN = N;
        while (M--) {
            int u, v;
            scanf("%d%d", &u, &v);
            G[u].push_back(v);
            G[v].push_back(u);
        }
        idx = 0;
        Tarjan(1);
        len--;
        for (int i = 1; i <= N; i++) G[i].clear();
        idx0 = 0;
        DFS(1, 0);
        for (int i = 1; i <= NN; i++) H[i].clear();
        scanf("%d", &Q);
        while (Q--) {
            scanf("%d", &S);
            for (int i = 1; i <= S; i++) scanf("%d", &A[i]);
            sort(A + 1, A + S + 1, cmp);
            int ANS = 0;
            for (int i = 1; i <= S; i++) ANS += Dis(A[i], A[i % S + 1]);
            ANS /= 2;
            if (LCA(A[1], A[S]) <= N)
                ANS++;
            printf("%d\n", ANS - S);
        }
    }
}
