#include <bits/stdc++.h>
using namespace std;

const int p = 998244353, inv2 = (p + 1) / 2;
void inline check(int &x) { x -= p, x += x >> 31 & p; } //����ȡģ 
int N, M;

int pow2[100005];
int f[400005], g[400005], sf[400005], lzy[400005];
void add(int x, int k) {
    check(g[x] = 1LL * g[x] * pow2[k] % p + 1 - pow2[k] + p);
    lzy[x] += k;
}
void pushup(int x) {
    check(sf[x] = f[x] + sf[x << 1]);
    check(sf[x] += sf[x << 1 | 1]);
}
void pushdown(int x) {
    if (!lzy[x])
        return;
    add(x << 1, lzy[x]);
    add(x << 1 | 1, lzy[x]);
    lzy[x] = 0;
}
void Update(int x, int l, int r, int L, int R) {
    if (r < L || l > R) {  // orange
        check(f[x] += g[x]);
        f[x] = 1LL * f[x] * inv2 % p;
        pushup(x);
        return;
    }
    if (L <= l && r <= R) {  // red
        f[x] = 1LL * (f[x] + 1) * inv2 % p;
        g[x] = 1LL * (g[x] + 1) * inv2 % p;
        if (l != r)
            pushdown(x), add(x << 1, 1), add(x << 1 | 1, 1);  // gray
        pushup(x);
        return;
    }
    f[x] = 1LL * f[x] * inv2 % p, g[x] = 1LL * g[x] * inv2 % p;  // white
    int mid = (l + r) >> 1;
    pushdown(x);
    Update(x << 1, l, mid, L, R);
    Update(x << 1 | 1, mid + 1, r, L, R);
    pushup(x);
}

int main() {
    pow2[0] = 1;
    for (int i = 1; i <= 100000; i++) pow2[i] = 1LL * pow2[i - 1] * inv2 % p;
    scanf("%d%d", &N, &M);
    int ans = 1;
    for (int i = 1; i <= M; i++) {
        int opt;
        scanf("%d", &opt);
        if (opt == 1) {
            int L, R;
            scanf("%d%d", &L, &R);
            Update(1, 1, N, L, R);
            check(ans += ans);
        } else
            printf("%d\n", 1LL * sf[1] * ans % p);
    }
}
