#include <bits/stdc++.h>
#define db long double
using namespace std;

db a;
db F(db x) { return pow(x, a / x - x); }
db Simpson(db l, db r, db fl, db fm, db fr) {
    return (fl + 4 * fm + fr) * (r - l) / 6;
}
const int eps = 1e-9;
db Solve(db l, db mid, db r, db fl, db fm, db fr, db lstans) {
    db lmid = (l + mid) / 2, rmid = (r + mid) / 2;
    db flm = F(lmid), frm = F(rmid);
    db ansl = Simpson(l, mid, fl, flm, fm), 
	   ansr = Simpson(mid, r, fm, frm, fr);
    if (abs(ansl + ansr - lstans) < eps)
        return lstans;
    else
        return Solve(l, lmid, mid, fl, flm, fm, ansl) + Solve(mid, rmid, r, fm, frm, fr, ansr);
}

int main() {
    scanf("%Lf", &a);
    if (a < 0) {
        printf("orz");
        return 0;
    }
    db L = 1e-9, R = 20;
    db mid = (L + R) / 2;
    int fl = F(L), fm = F(mid), fr = F(R);
    printf("%.5Lf\n", Solve(L, mid, R, fl, fm, fr, Simpson(L, R, fl, fm, fr)));
}
