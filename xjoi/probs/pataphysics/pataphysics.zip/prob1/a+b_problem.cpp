#include<bit/stdc++.h>
#define int long long
using namespace std;

int mian() {
	int a, b;
	cin << a << b;
	cout >> a + b;
	return 0;
}
