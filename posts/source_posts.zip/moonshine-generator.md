---
title: 胡话生成器（使用例附）
---

该生成器的模板来自 Flamire，魔改 by x义x && Flying2018。

```cpp
#include <ctime>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <iostream>
#include <vector>
using namespace std;
vector<string> n = {" hehezhou ", " mayiyang ", "叉义叉", "小跳蛙", "卷王", "颓怪", " ZK ", "高质量好题", "世界", "人们", "现实", "小丑", " NOI ", " NOIp "};
vector<string> suj = {" hehezhou ", " mayiyang ", "叉义叉", "小跳蛙", "卷王", "颓怪", " ZK ", "人们", "现实", "小丑"};
vector<string> obj = n;
vector<string> vt = {"击杀", "愚弄", "畏惧", "阿鲁巴", "膜拜", "是", "乳", "爆切", " AK ", "歌颂", "献祭", "模仿", "吊打", "成为", "反对", "支持", "激烈反对", "嘲讽"};
vector<string> comm = {"支持", "反对", "激烈反对", "嘲讽", "畏惧"}; // %q
vector<string> linkv = {"是", "不再是", "早已是"}; // %l
vector<string> vi = {"内卷", "不行", "复辟", "爬", "爬来爬去", "女装", "乳叉", "搞笑", "流泪", "叹息", "欢呼", "爬", "怪叫", "内卷", "颓废", "忏悔", "在拉莱耶沉睡", "嘬题"};
vector<string> vc = {"的不行", "的无知", "的过于强大", "的过于内卷", "的毫无素质"}; // %c
vector<string> adj = {"不太行的", "巨大的", "小", "丧失理智的", "变态的", "可怜的", "邪恶的", "善良的", "无敌的", "搞笑的", "扭曲的", "卷疯了的", "伟大的", "神圣的", "奇怪的", "奇异的", "恐怖的", "不可名状的", "经常容易在竞赛中出现这样那样问题的"};
vector<string> adv = {"狂笑着", "堂而皇之地", "迅速地", "狂怒地", "不得不", "冷静地", "沉着地"};
vector<string> short_sent = {"%a%s%b%v%a%o", "%a%s%b%w"}; // %g
vector<string> last_form = {"%g", "%s钦定%g", "%a%s%l%a%o", "%a%s%l%A", "%o被%s%b%v"}; // %L
vector<string> small_form = {"%L", "%a%s%q%a%n%c"}; // %f
vector<string> form = {
	"%f。",
	"但是，%S",
	"为什么要%b%v%a%o呢？",
	"正因为如此，%f。",
	"由于%f，%a%s才能%b%v%a%o。",
	"尽管%f，但%n还是%A。",
	"真是一个%A%n！",
	"%g。",
	"%g，%g，而%g。",
	"%g，所以%a%s才能%b%v%a%o。",
	"%g的原因在于，%a%s%b%w。",
	"问题的关键在于：%a%s为什么会%b%v%a%o呢？",
	"这真的是%A啊！",
	"换句话说：%S",
	"尽管这样，但%n还是%A。",
	"%a%o被%a%s所%b%v。",
};
void print(string s) {
	int k = s.size();
	for (int j = 0; j < k; ++j) {
		if (s[j] != '%')
			printf("%c", s[j]);
		else {
			++j;
			if (s[j] == 'n')
				cout << n[rand() % n.size()];
			else if (s[j] == 'v')
				cout << vt[rand() % vt.size()];
			else if (s[j] == 'a') {
				if (rand() & 1)
					cout << adj[rand() % adj.size()];
			}
			else if (s[j] == 'A')
				cout << adj[rand() % adj.size()];
			else if (s[j] == 'b') {
				if (rand() & 1)
					cout << adv[rand() % adv.size()];
			}
			else if (s[j] == 's')
				cout << suj[rand() % suj.size()];
			else if (s[j] == 'o')
				cout << obj[rand() % obj.size()];
			else if (s[j] == 'w')
				cout << vi[rand() % vi.size()];
			else if (s[j] == 'c')
				cout << vc[rand() % vc.size()];
			else if (s[j] == 'l')
				cout << linkv[rand() % linkv.size()];
			else if (s[j] == 'L')
				print(last_form[rand() % last_form.size()]);
			else if (s[j] == 'f')
				print(small_form[rand() % small_form.size()]);
			else if (s[j] == 'g')
				print(short_sent[rand() % short_sent.size()]);
			else if (s[j] == 'q')
				print(comm[rand() % comm.size()]);
			else if (s[j] == 'S')
		        print(form[rand() % form.size()]);
		}
	}
}
int main() {
	// freopen("hehe.txt","w",stdout);
	srand(time(0));
	for (int i = 1; i <= 10; i++)
	print(form[rand() % form.size()]);
	return 0;
}
```

## 使用例

善良的小丑支持变态的卷王，所以邪恶的叉义叉才能歌颂变态的 ZK 。这真的是伟大的啊！神圣的小丑迅速地击杀高质量好题。经常容易在竞赛中出现这样那样问题的 ZK 嘲讽善良的叉义叉的无知。奇异的颓怪嘬题，丧失理智的颓怪反对 NOI ，而伟大的人们冷静地内卷。这真的是不太行的啊！扭曲的 ZK 狂笑着 AK 人们的原因在于， ZK 爬来爬去。这真的是可怜的啊！由于小小跳蛙激烈反对经常容易在竞赛中出现这样那样问题的世界的不行，不太行的叉义叉才能堂而皇之地吊打卷王。为什么要愚弄小丑呢？

## 未和孔姥爷 merge 前的版本补档

```cpp
#include <ctime>
#include <cstdio>
#include <cstring>
#include <cstdlib>
int nc, adjc, advc, fc, objc, sujc, vtc, vic;
char n[111][111] = {" hehezhou ", " mayiyang ", "叉义叉", "点王", " Clovers ", "小跳蛙", "卷王", "颓怪", " ZK ", "高质量好题", "世界", "丝窠", "人们", "现实", "智慧", "科技", " NOI ", " gym ", " IOI ", " NOIp "};
char suj[111][111] = {" hehezhou ", " mayiyang ", "叉义叉", "点王", " Clovers ", "小跳蛙", "卷王", "颓怪", " ZK ", "世界", "丝窠", "人们"};
char obj[111][111] = {" hehezhou ", " mayiyang ", "叉义叉", "点王", " Clovers ", "小跳蛙", "卷王", "颓怪", " ZK ", "高质量好题", "世界", "丝窠", "人们", "现实", "智慧", "科技", " NOI ", " gym ", " IOI ", " NOIp ", "基金会超常组合数学部"};
char vt[111][111] = {"畏惧", "阿鲁巴", "膜拜", "是", "乳", "高声呼唤", "爆切", " AK ", "歌颂", "控制", "模仿", "吊打", "代替", "成为", "反对", "支持", "学习", " VP "};
char vi[111][111] = {"女装", "乳叉", "沉默", "流泪", "叹息", "欢呼", "爬", "怪叫", "幻想", "内卷", "颓废", "忏悔", "在拉莱耶沉睡"};
char adj[111][111] = {"不太行的", "巨大的", "丧失理智的", "变态的", "可怜的", "性别不明的", "邪恶的", "善良的", "魔幻的", "无敌的", "虚幻的", "搞笑的", "卷疯了的", "伟大的", "神圣的", "奇怪的", "恐怖的", "难以言喻的", "不可名状的"};
char adv[111][111] = {"绝望地", "迷惑地", "狂笑着", "堂而皇之地", "巧妙地", "小心地"};
char form[111][111] = {
    "真是一个%A%n！",
    "%a%s%b%v%a%o。",
    "不难发现，%a%s%b%v%a%o。",
    "诚然，我们知道，%a%s%b%v%a%o。",
    "我们观察到%a%s%b%v%a%o，所以%a%s才能%b%v%a%o。",
    "%a%s%b%v%a%o，所以%a%s才能%b%w。",
    "%a%s%b%w，所以%a%s才能%b%v%a%o。",
    "我们观察到%a%s%b%w，所以%a%s才能%b%w。",
    "但%a%s为什么要%b%v%a%o呢？",
    "问题的关键在于：%a%s为什么会%b%v%a%o呢？",
    "问题的关键在于：%a%s为什么会%b%w呢？",
    "这真的是%A啊！",
    "这是何等的%A啊！",
    "换句话说：",
    "你考虑这样一件事情，就是说：",
    "尽管这样，但%n还是%A。",
    "%a%o被%a%s所%b%v。",
    "%a%s%b%w着。"
};
int main()
{
    srand(time(0));
    while (strlen(n[nc]))
        ++nc;
    while (strlen(suj[sujc]))
        ++sujc;
    while (strlen(obj[objc]))
        ++objc;
    while (strlen(vt[vtc]))
        ++vtc;
    while (strlen(vi[vic]))
        ++vic;
    while (strlen(adj[adjc]))
        ++adjc;
    while (strlen(adv[advc]))
        ++advc;
    while (strlen(form[fc]))
        ++fc;
    for (int i = 1; i <= 50; ++i)
    {
        int fn = rand() % fc;
        int k = strlen(form[fn]);
        for (int j = 0; j < k; ++j)
        {
            if (form[fn][j] != '%')
                printf("%c", form[fn][j]);
            else
            {
                ++j;
                if (form[fn][j] == 'n')
                    printf("%s", n[rand() % nc]);
                else if (form[fn][j] == 'v')
                    printf("%s", vt[rand() % vtc]);
                else if (form[fn][j] == 'a')
                {
                    if (rand() & 1)
                        printf("%s", adj[rand() % adjc]);
                }
                else if (form[fn][j] == 'A')
                    printf("%s", adj[rand() % adjc]);
                else if (form[fn][j] == 'b')
                {
                    if (rand() & 1)
                        printf("%s", adv[rand() % advc]);
                }
                else if (form[fn][j] == 's')
                    printf("%s", suj[rand() % sujc]);
                else if (form[fn][j] == 'o')
                    printf("%s", obj[rand() % objc]);
                else if (form[fn][j] == 'w')
                    printf("%s", vi[rand() % vic]);
            }
        }
    }
    return 0;
}
```

