---
title: soj#439 题解 - 兼 O(n^3) 矩阵特征多项式计算笔记
---

写这篇文章的 id 时我还斟酌了一下，因为我发现 eigen 和 characteristic 都被翻译成"特征"……

好了开始吧。

我们知道，可以用初等变换进行高斯消元以计算行列式的原因是，初等变换对行列式的影响非常简单，是 $1/-1$​​。

而对于本问题，我们的策略是使用相似变换：~~查阅 wiki 可得，~~相似变换是保持特征多项式的。于是我们来考虑一下有没有什么有用的相似变换。

比如：
$$
\begin{bmatrix}
1\\
&\ddots\\
&&1&k\\
&&&1\\
&&&&\ddots\\
&&&&&1
\end{bmatrix}\times A\times
\begin{bmatrix}
1\\
&\ddots\\
&&1&-k\\
&&&1\\
&&&&\ddots\\
&&&&&1
\end{bmatrix}
$$
的效果就是：

- $A$​ 的第 $i$​ 行 $+=$​ 第 $i+1$​ 行的 $k$​ 倍，然后（当然其实交换一下顺序也没关系）$A$​ 的第 $i+1$​ 列 $+=$​ 第 $i$​ 列的 $-k$​​ 倍。

而行交换这一初等变换导出的相似变换则是

- 交换 $A$ 的第 $i$ 行和第 $i+1$ 行；然后交换 $A$​ 的第 $i$ 列和第 $i+1$​ 列。

虽然每个矩阵确实都相似于一个上三角矩阵，但是仅用上面两个相似变换是做不到这一点的。（如果所有元素在任何时刻均不为 $0$​ 那确实可以消，但是会在一些 edge case 时很苦痛）事实上你会看到我们也不需要做到这一点。

这里我们改为消成一个 **Hessenberg 矩阵**，即比上三角矩阵再多一条斜线。消元方法很简单，和高斯消元一模一样（如果你手模过一些之前提到的 edge case，你会发现主对角线很难处理；而这里我们直接避开了主对角线）。最后按定义直接计算其特征多项式即可。（枚举第一列选什么，第二列选什么……，这个 DP 需要计算 $n^2$  个矩阵的行列式，转移是 $O(n)$ 的。）

代码如下。

为什么你们都这么松！！！

```cpp
#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

const int p = 998244353;
void check(ll &x) { if (x >= p) x -= p; }

ll qpow(ll a, int k) {
    ll ans = 1;
    while (k) {
        if (k & 1) (ans *= a) %= p;
        (a *= a) %= p;
        k >>= 1;
    }
    return ans;
}

const int maxn = 605;
int n, lim;
void add(ll a[][maxn], int u, int v, ll K) {
    for (int i = 0; i < n; i++) (a[v][i] += K * a[u][i]) %= p;
    for (int i = 0; i < n; i++) check(((a[i][u] -= K * a[i][v]) %= p) += p);
}
void swp(ll a[][maxn], int u, int v) {
    for (int i = 0; i < n; i++) swap(a[u][i], a[v][i]);
    for (int i = 0; i < n; i++) swap(a[i][u], a[i][v]);
}

void add1(ll u[], ll v[], ll K) {
    for (int i = 0; i < lim; i++) (u[i] += 1LL * v[i] * K) %= p;
}
void add2(ll u[], ll v[]) {
    for (int i = 0; i < lim; i++) check(u[i + 1] += v[i]);
}

ll f_[2][maxn][maxn]; auto f = f_[0], tf = f_[1];
void Chara(ll a[][maxn], ll ans[]) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = i + 2; j < n && !a[i + 1][i]; j++)
            if (a[j][i]) swp(a, i + 1, j);
        if (a[i + 1][i] == 0) continue;  // 全 0 
        for (int j = i + 2; j < n; j++) {
            ll K = qpow(a[i + 1][i], p - 2) * a[j][i] % p;
            add(a, i + 1, j, p - K);
            assert(a[j][i] == 0);
        }
    }

    f[0][0] = 1;
    for (int i = 0; i < n; i++) {
        lim = i + 1;
        for (int j = 0; j <= i + 1; j++) memset(tf[j], 0, maxn * sizeof(ll));
        for (int j = 0; j <= i; j++) {
            add1(tf[i + 1], f[j], p - a[j][i]);
            if (j == i) add2(tf[i + 1], f[j]);
            if (i + 1 < n) add1(tf[j], f[j], a[i + 1][i]);
        }
        swap(f, tf);
    }
    for (int i = 0; i <= n; i++) ans[i] = f[n][i];
}

ll a[maxn][maxn];

int main() {
    scanf("%d", &n);
    for (int i = 0; i < n; i++)
    for (int j = 0; j < n; j++)
        scanf("%lld", &a[i][j]);
    ll ans[maxn]; Chara(a, ans);
    for (int i = 0; i <= n; i++) printf("%lld ", ans[i]);
}
```

