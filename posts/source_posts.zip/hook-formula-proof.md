---
title: 论文翻译：钩长公式的一个概率论证明
---

论文链接：[这里](https://www2.math.upenn.edu/~wilf/website/Probabilistic%20proof.pdf)

记 $F(\lambda_1,...)=\begin{cases}\texttt{该形状对应的标准杨表数}&(\lambda_1\ge\lambda_2\ge\ldots)\\0&\text{otherwise}\end{cases}$。

考虑元素 $n$ 所在的位置，它一定在某个角落，我们自然有
$$
F(\lambda_1,...)=\sum_iF(\lambda_1,\ldots,\lambda_i-1,\ldots)
$$
此后我们将其简记为
$$
F=\sum_{\alpha}F_{\alpha}
$$
我们只需要证明，钩长公式亦满足这个递推，从而 $F$ 一定就是钩长公式本身。

现在来考虑依托某杨图的一个随机过程：在 $n$ 个格子里随机选一个，然后在该格子的钩子中随机选一个，……，直到当前格子已经是一个边角。设该随机过程终结于格子 $(\alpha,\beta=\lambda_{\alpha})$ 的概率为 $p(\alpha,\beta)$。

我们只需要证明一件事：
$$
p(\alpha,\beta)=\dfrac{1}{n}\prod_{1\le i<\alpha}\left(1+\dfrac{1}{h_{i,\beta}-1}\right)\prod_{1\le j<\beta}\left(1+\dfrac{1}{h_{\alpha,j}-1}\right)
$$
然后，由于显然 $\sum p(\alpha,\beta)=1$，所欲证的结论就立即得出了。

固定 $\alpha,\beta$。记 $p(A,B)$ 是该随机过程终结于格子 $(\alpha,\beta)$，且路径上所有经过的横坐标的集合为 $A$，纵坐标的集合为 $B$ 的概率。

讨论第一步是 $A_1\rightarrow A_2$ 还是 $B_1\rightarrow B_2$ 可以得到一个归纳，由归纳易得：
$$
p(A,B)=\dfrac 1n\prod_{i\in A,i\neq\alpha}\dfrac{1}{h_{i,\beta}-1}\cdot\prod_{j\in B,j\neq\beta}\dfrac{1}{h_{\alpha,j}-1}
$$
然后显然有
$$
p(\alpha,\beta)=\sum_{A,B}p(A,B)
$$
即得证。



