---
title: luoguP6980 题解 - 【NEERC2015】Hypercube
---

> **题目大意.**
>
> 给出 $8$ 个粘在一起的立方体。求它们是不是四维超立方体的一种展开图。

我们先来考虑一下 $3$​ 维的简单情形。

怎么判定一个立方体是否是展开图？很简单，向下、向上、向左、向右、向前、向后的面恰有一个。

而如何推出一个面的方向？注意下图中各面方向的递推关系。

<div style="width:80%;margin:auto"><img src="https://xyix.github.io/images/luogu-6980-1.png" alt=""></div>

注意面的状态是不能用上下左右前后简单概括的，换句话说向上和向上可能并不相同。这里的策略是直接大力保存其单位向量被映射到了何处。

<div style="width:80%;margin:auto"><img src="https://xyix.github.io/images/luogu-6980-2.png" alt=""></div>

于是四维的情况也就容易类比了。

```cpp
#include<bits/stdc++.h>
using namespace std;

char s[10][10][10];
int sum;

void solve(int x, int y, int z, vector<int> a) {
    s[x][y][z] = '.';
    // printf("check %d %d %d %d\n", a[0], a[1], a[2], a[3]);
    sum |= 1 << a[0];
    if (s[x + 1][y][z] == 'x')
        solve(x + 1, y, z, {7 ^ a[1], a[0], a[2], a[3]});
    if (s[x - 1][y][z] == 'x')
        solve(x - 1, y, z, {a[1], 7 ^ a[0], a[2], a[3]});
    if (s[x][y + 1][z] == 'x')
        solve(x, y + 1, z, {7 ^ a[2], a[1], a[0], a[3]});
    if (s[x][y - 1][z] == 'x')
        solve(x, y - 1, z, {a[2], a[1], 7 ^ a[0], a[3]});
    if (s[x][y][z + 1] == 'x')
        solve(x, y, z + 1, {7 ^ a[3], a[1], a[2], a[0]});
    if (s[x][y][z - 1] == 'x')
        solve(x, y, z - 1, {a[3], a[1], a[2], 7 ^ a[0]});
}

int main() {
    freopen("hypercube.in", "r", stdin);
    freopen("hypercube.out", "w", stdout);
    int L, W, H;
    int x, y, z;
    scanf("%d%d%d", &H, &W, &L);
    for (int i = 1; i <= L; i++)
    for (int j = 1; j <= W; j++) {
        scanf("%s", s[i][j] + 1);
        for (int k = 1; k <= H; k++)
            if (s[i][j][k] == 'x') x = i, y = j, z = k;
    }
    solve(x, y, z, {0, 1, 2, 3});
    printf(sum == 255 ? "Yes\n" : "No\n");
}
```

