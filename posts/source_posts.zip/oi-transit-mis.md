---
title: OI-transit 随机做
---

### luoguP7028 - 【NWRRC2017】Joker

**项目等级**：Safe

**威胁等级**：<span style='color: orange; font-weight: bold'>橙色</span>

> **题目大意.**
>
> > 现在有一个序列 $a_i$，设其中正数的和为 $P$，负数的和为 $N$。定义：
> > $$
> > s_i=s_{i-1}+\begin{cases}a_i/P&(a_i>0)\\a_i/|N|&(a_i<0)\end{cases}
> > $$
> > 问 $s$ 的最大值是多少。
>
> 现在有 $m$ 次修改 $a_i$ 的操作，问每次操作结束后以上问题的答案。
>
> $n,m\le 5\times10^4$，时限 3s。

不妙的数据范围……

考虑把 $s_i$ 看成 $(\sum[a_i>0]a_i,\sum[a_i<0]a_i)$，那么所要求的值就是 $s_i$ 与 $(1/P,1/|N|)$ 的点积。

凸包，带修改，还要在线，自然考虑分块。

为了支持修改，我们看似要支持后缀平移，但是平移的量可以直接看成一个 lazytag。

时间复杂度为 $mB$（散块暴力重构）（注意点的坐标单调增，不然还得再阴间一点）+ $m(n/B)$（打 lazytag）+ $m(n/B)\log B$（对各块的凸包进行二分）。

当 $B=\sqrt{n\log n}$ 时就获得了 $O(m\sqrt{n\log n})$ 的复杂度。

### CF1416E - Split

**项目等级**：Keter

**威胁等级**：<span style='color: red; font-weight: bold'>红色</span>

> **题目大意.**
>
> 现在有一个非负整数序列 $a$，你要把每个 $a_i$ 拆成 $b_{2i-1}+b_{2i}=a_i$，使得 $b$ 中同色连续段尽量少。
>
> $n\le 5\times10^5$。

**key observation**：我们可以预先钦定那些 $b_{2i}\neq b_{2i+1}$ 的位置，此时每一段互相独立且段内（必定有 $b_{2i}=b_{2i+1}$）情况数非常有限。

只要我们确定了某一段的开头元素，不妨记为 $x$，就能解出整个段。当然有一些形如下述的约束：

- 必须有 $x\in[L,R]$；
- 若 $x=X$，则代价 $-1$。

我们可以考虑把整个序列设为为一整段并解出，这样，对于每一段都只需要把 $L,R,X$ 平移一下。但事实上我们也并不关心 $L,R,X$ 的绝对位置，所以就拿这玩意当真实的 $L,R,X$ 吧。

从而，当 $i$ 移动时，我们只需要支持：

- 区间赋为 $+\infty$；（$L_i,R_i$ 的约束）
- 单点 $-1$；（$X_i$）
- 区间对某个值取 min；（$i-1$ 变得可用）
- 询问全局最小值。

这是~~不难~~可以维护的。

### CF1375H - Set Merging

**项目等级**：Euclid

**威胁等级**：<span style='color: green; font-weight: bold'>绿色</span>

> **题目大意.**
>
> 现在有一个 $1\sim n$ 的排列 $p$。现有 $n$ 个集合，每个都形如 $\{i\}$。
>
> 如果你持有集合 $S,T$，并且 $\max p_S<\min p_T$ 或反之，那么你就可以获得集合 $S\cup T$（$S,T$ 不消失），这被称为一个**合并**操作。
>
> 现在指定 $q$ 个区间 $[l_i,r_i]$，请在 $2.2\times10^6$ 次操作内造出这些区间。
>
> $n\le 4096,q\le 65536$。

自然考虑分治：我们对值域分治，然后……嗯？一个编号区间可能会被拆得很散，似乎分治没有优化效果。

我们来猜猜复杂度！$4096\times 512=2097152$。~~而且又观察到这场的出题人有 Ynoi。~~难道是个根号题？

自然考虑对值域分块。但是在此处分块有什么用？【一个大小为 $B$ 的块中只有 $B^2$ 种区间。】如果我们把它们全部预处理出来呢？

如何预处理？这时分治的意义就浮现了：如果我们的目标是处理【每一种区间】，分治可以确保每个区间只需要恰好一次合并。

时间复杂度 $O(nB+qn/B)$，当 $B$ 取 $\sqrt q$ 时即可获得 $O(n\sqrt q)$ 的复杂度。

```cpp
#include <bits/stdc++.h>
using namespace std;
typedef pair<int, int> pii;

pii op[2200000];
int CNT;
int M(int A, int B) {
	if (A && B) { op[++CNT] = pii(A, B); return CNT; }
	return A + B;
}

struct block {
	int n;
	int val[512];
	vector<int> f;
	block () {}
	block (int tval[], int tn) {
		n = tn;
		if (n == 1) {
			val[0] = tval[0];
			f.push_back(tval[0]);
			return;
		}
		int mid = n / 2;
		block L(tval, mid), R(tval + mid, n - mid);
		merge(L.val, L.val + L.n, R.val, R.val + R.n, val);
		f.resize(n * (n + 1) / 2);
		for (int r = 0; r < n; r++)
		for (int l = 0; l <= r; l++)
			f[l + (r + 1) * r / 2] = M(L.query(val[l], val[r]), R.query(val[l], val[r]));
	}
	int query(int L, int R) const {
		L = lower_bound(val, val + n, L) - val;
		R = upper_bound(val, val + n, R) - val - 1;
		return L <= R ? f[L + (R + 1) * R / 2] : 0;
	}
};

int n, cntB;
int pos[4100], ans[66000];
block s[512];

int main() {
	int q;

	scanf("%d%d", &n, &q);
	cntB = ((n - 1) >> 8) + 1;
	CNT = n;

	for (int i = 1; i <= n; i++) {
		int x; scanf("%d", &x);
		pos[x] = i;
	}
	for (int i = 0; i < cntB; i++) {
		int L = (i << 8) + 1, R = min((i + 1) << 8, n);
		int lis[512]; memset(lis, 0, sizeof(lis));
		for (int j = L; j <= R; j++) lis[j - L] = pos[j];
		s[i] = block(lis, R - L + 1);
	}

	for (int i = 1; i <= q; i++) {
		int l, r; scanf("%d%d", &l, &r);
		for (int j = 0; j < cntB; j++)
			ans[i] = M(ans[i], s[j].query(l, r));
	}

	printf("%d\n", CNT);
	for (int i = n + 1; i <= CNT; i++) printf("%d %d\n", op[i].first, op[i].second);
	for (int i = 1; i <= q; i++) printf("%d ", ans[i]);
}
```

### uoj#84 - 水题走四方

**项目等级**：Keter

**威胁等级**：<span style='color: orange; font-weight: bold'>橙色</span>

> **题目大意.**
>
> 现在有一棵树和两个地卜师，地卜师初始时都在根节点。地卜师可以随时独立进行以下操作：
>
> - 向某个儿子走一步，花费时间 $1$；
> - 传送到另一个地卜师处，不消耗时间。
>
> 问，至少花多长时间就可以遍历这棵树。
>
> $n\le 5\times10^5$。

不妨认为其中一个地卜师（称为 A）不会瞬移，那么它的路径应当恰是一条链。

那么策略就是：A 选定一个子树，B 处理掉所有别的子树，然后 A 走进选定的子树。如此循环。……吗？

然而并不。B 再走最后一条链时，如果 A 的接下来几步都没有其他儿子，那么 A 就可以选择和 B 同时行动压缩时间。

……那么这样就好了吗？来看这个 case：

<div style="width:30%;margin:auto"><img src="https://xyix.github.io/images/uoj-84.png" alt=""></div>

好吧，看来这个问题并没有想的那么简单。

---

我们不妨预先约定一些点为"传送点"，B 可以通过传回传送点来走到其他叶子。

- 一个叶子被处理所需的时间恰是它向上走走到第一个"传送点"的时间。（如果我们认为 A 的目的地也是传送点的话）

那么问题就来了，答案是否就是所有叶子被处理的时间之和呢？然而并不，B 等 A 的情况也是有可能出现的。不过，我们一定会让 B 的最后一步是去处理一个最深的叶子，这样 B 等 A 的时间就能尽可能短。

由此，我们对每个点 $u$ 枚举它上一个关键点，就可以得到一个 $O(n^2)$ DP。

---

我们不妨直接不承认 B 等 A，而是让 B 处理完之后立刻传回 A 并和 A 一起走，这段一起走的路径我们认为全是关键点。

转移就变为
$$
f(u)=\min_{u\in T(v);\color{red}存在一个T(v)中的叶子不浅于u}f(v)+\text{sdep}(T(v)/T(u))
$$
如果 $fa(u)$ 只有 $u$ 一个儿子，则还有以下转移
$$
f(u)=f(fa(u))+1
$$
仔细一想你会发现，直观地来说，所有合法的 $v$ 都要处理【$v$ 中最深者 $v_m$】的子树中的一个很深的叶子，因此对它们来说把 $v_m$ 设为关键点肯定不劣。因此，我们只需要找到这个 $v_m$ 做转移即可。

---

那么问题又来了，怎么找呢？

考虑某个特定子树，该子树中最多只有一个叶子（即深度最大者）和它的一小段祖先未确定它们的 $v_m$。强行合并即可。（这题的输入格式还非常友好，直接给了括号序列。）

```cpp
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

const int maxn = 5000054;

int n;
int fa[maxn], deg[maxn];
int dep[maxn], siz[maxn], mdep[maxn];

int suc[maxn];
int VM[maxn];

ll ans[maxn], sdep[maxn];
char s[maxn * 2];

void link(int x, int y) { fa[x] = y; deg[y]++; dep[x] = dep[y] + 1; }

int main() {
	scanf("%d%s", &n, s);
	int now = 0, cnt = 0;
	for (int i = 0; i < n + n; i++) {
		if (s[i] == '(') link(++cnt, now), now = cnt;
		else now = fa[now];
	}
	for (int x = n; x > 1; x--) {
		if (!deg[x]) siz[x] = 1, sdep[x] = mdep[x] = dep[x];

		int fax = fa[x];
		siz[fax] += siz[x];
		int tdep = mdep[fax];
		mdep[fax] = max(mdep[fax], mdep[x]);
		sdep[fax] += sdep[x];

		int u, v;
		for (u = x; u && dep[u] <= tdep; u = suc[u]) VM[u] = fax;
		for (v = suc[fax]; v && dep[v] <= mdep[x]; v = suc[v]) VM[v] = fax;
		suc[fax] = u + v;
	}

	// for (int i = 1; i <= n; i++) printf("%d : %d\n", i, VM[i]);

	memset(ans, 63, (n + 1) * sizeof(ll)); ans[1] = 0;
	ll ANS = 0x3f3f3f3f3f3f3f3fLL;
	for (int x = 1; x <= n; x++) {
		int y = VM[x];
		if (y) ans[x] = min(ans[x], ans[y] + (sdep[y] - sdep[x]) - (ll)dep[y] * (siz[y] - siz[x]));
		if (deg[fa[x]] == 1) ans[x] = min(ans[x], ans[fa[x]] + 1);
		if (!deg[x]) ANS = min(ANS, ans[x]);
	}
	printf("%lld\n", ANS);
	return 0;
}
```

### loj#6534 - 有趣的题

**项目等级**：Safe

**威胁等级**：<span style='color: green; font-weight: bold'>绿色</span>

> **题目大意.**
>
> 现在有一个集合 $S$，其中有许多对 $(a_i,b_i)$。
>
> 定义
> $$
> F(S,X)=\min a_i+F(S/\{i\},b_i+\max(X-a_i,0))
> $$
> （额外约定 $F(\varnothing,X)=X$）
>
> 问 $F(S,0)$。
>
> $|S|\le 2\times10^6$。时限 250ms。

不妨考虑预先约定 $(a_i,b_i)$ 的删除顺序然后一个一个取；而答案就是所有删除顺序中权值最小的。

以 $n=3$ 的情形为例，一顿展开后可以得到：一个方案的权值为
$$
\max(a_1+b_3+b_2+b_1,b_3+b_2+a_1+a_2,b_3+a_1+a_2+a_3)
$$
即，在形如下图的一个网格中游走，所有路径中权值和的最大值。
$$
\begin{matrix}a_1&a_2&\ldots&a_n\\b_1&b_2&\ldots&b_n\end{matrix}
$$
那么现在的问题就是：如何排列这些 $(a_i,b_i)$ 使得答案最小。

---

考虑两个相邻的 $(a_i,b_i)$ 和 $(a_{j},b_j)$。我们什么时候应该让 $i$ 排在 $j$ 前面？
$$
a_i+b_j+\max(b_i,a_j)<b_i+a_j+\max(a_i,b_j)\\
\max(-a_j,-b_i)<\max(-a_i,-b_j)\\
\boxed{\min(a_j,b_i)>\min(a_i,b_j)}
$$
哎，然后就直接过了？为啥？怎么证传递性和不可比性的传递性？（如果你不知道这是什么，请看[这里](https://ouuan.github.io/post/%E6%B5%85%E8%B0%88%E9%82%BB%E9%A1%B9%E4%BA%A4%E6%8D%A2%E6%8E%92%E5%BA%8F%E7%9A%84%E5%BA%94%E7%94%A8%E4%BB%A5%E5%8F%8A%E9%9C%80%E8%A6%81%E6%B3%A8%E6%84%8F%E7%9A%84%E9%97%AE%E9%A2%98/)）

---

根据以上条件，我们有以下推论：

- 如果 $a_i>b_i\land a_j\le b_{j}$，那么 $i$ 放在 $j$ 后面一定不劣。

于是我们可以把元素分成两类：$a_i>b_i$ 和 $a_j\le b_j$。对于前者，可以用同样的方法证明其内部要按 $b_i$ 降序排列；对于后者，其内部要按 $a_i$ 升序排列。

### luoguP7056 - 【NWRRC2015】Insider's Information

这种题对叉义叉来说可能还是为时过早