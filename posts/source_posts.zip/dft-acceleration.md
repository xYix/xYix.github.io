---
title: DIT 和 DIF：DFT 的优化
---

一目了然，不言而喻：

<div style="width:70%;margin:auto"><img src="https://xyix.github.io/images/DIF_DIT.jpg" alt=""></div>

据说在 ln / exp 时效果很好。