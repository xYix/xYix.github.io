---
title: luoguP7115 题解 - 【NOIP2020】移球游戏
---

我是一个非常讨厌补题的人，看到自己挣扎了大半天啥也没搞出来的题被别人用一个奇妙的观察或是神秘的猜想暴切的感觉真的非常令人沮丧。更何况补题还意味着重温当时的绝望心境。不是什么东西都是可以用努力和认真思考换来的，cnm。

一想到这题我就有很多话想说。对 NOIP 的难度变化和出题趋势毫无了解却至今还在自满自大的教练，觉得这题真的不难（他们是真心的，我认为他们已经在努力照顾别人的感受了）怒拿 100 的同学，和 NOIP2018 刚摆渡车刚了半场还过了大样例最后却只拿了 40 时如出一辙的绝望。与之相比 T1 CE 倒显得像是个不值一提的小事。这些我全都一点都不想再去思考了，但我的 sb 潜意识最 tm 喜欢的就是抽出那些让我或痛苦或尴尬或不适的回忆一遍一遍重放。艹。

> **题目大意.**
>
> 现有有 $n+1$ 根柱子，其中柱前 $n$ 根柱子子上各有 $m$ 个球，$n+1$ 号柱子上没有球。这 $n\times m$ 个球共有 $n$ 种颜色，每种颜色的球恰 $m$ 个。
>
> 你的任务是在 $820000$ 次操作内把所有同种颜色的球移到同一根柱子上。（具体哪根柱子对应哪个颜色不作要求）注意你要时刻保证任何柱子的球数不超过 $m$。
>
> $n\le 50,m\le 400$。

先来考虑直接暴力逐列还原：还原第 $i$ 列时它的顶端恰好有一堆颜色为 $i$ 的球。

> **算法一.**
>
> 显然，我们可以在平均 $2m$ 步内把新的一个颜色为 $i$ 的球加到它的底下，原来底下那个球则与它交换。
>
> <div style="width:60%;margin:auto"><img src="https://xyix.github.io/images/luogu-7115.png" alt=""></div>
>
> 注意，为了避免无意义的复位，空列的位置改变了。
>
> 总用时为 $2m^2\cdot\dfrac{n}{2}=m^2n$。

可见，以上算法效率不够高的关键原因在于：它每次只能处理一个球，而不是能立刻把某一列的所有颜色为 $i$ 的球提出来。这个效率相差还是很大的。下面我们朝这个方向努力。

> **算法 2.**
>
> 我们可以在 $m$ 步内让某个栈内所有颜色为 $i$ 的球提到顶部，并用它替换一些我们挑选出来的"祭品"。（最后，当所有颜色为 $i$ 的球都"暴露"了出来时，直接全部拿出来就好了。）
>
> <div style="width:30%;margin:auto"><img src="https://xyix.github.io/images/luogu-7115-1.png" alt=""></div>
>
> 这时必须仔细考虑策略：我们不希望动用其他颜色为 $i$ 的球作为祭品（否则我们就要把放祭品的那个栈翻回来以使这些球重新暴露），那么祭品的数量是否总是足够？
>
> 答案是否（比如，如果颜色数相对 $m$ 较少，这种 cases 将非常容易构造）。所以我们真的有可能每一次都要倒带，总时间为为 $2\times m\times n^2/2=mn^2$。

为了避免倒带，或许我们该考虑构造一个完全没有 $i$ 的列：这个列一旦构造出来就会长久存在（观察之前的过程，可能会有换血但始终有这样一个列），非常有用。

> **算法 3.**
>
> 第一列和第二列中非 $i$ 的数量必定是足够的。因此只需要针对它们进行构造。
>
> - 献祭第二列的顶端，提出第一列中的所有 $i$。
> - 献祭原第一列的 $i$ 们，提出原第二列的顶端中的所有 $i$。倒带一次。
> - 此时所有 $i$ 已经在顶端，扔到空列，整理，结束。
>
> 时间为 $5m$。

故，总时间变为 $m\times n^2/2+5\times n\approx 500200$，绰绰有余。

（由于常数原因实测其实是 $660000+$，反正问题不大）

```cpp
#include <bits/stdc++.h>
#pragma GCC optimize("Ofast")
using namespace std;

const int maxn = 55;

int n, m;
vector<pair<int, int> > ans;
vector<int> A[maxn];
int stat[maxn], emp; // -1 : empty, 1 : finished
void move(int i, int j) {
    assert(A[i].size() && A[j].size() != m);
    ans.push_back(make_pair(i, j));
    A[j].push_back(A[i].back()); A[i].pop_back();
}
int back(int i) { return A[i].back(); }
void move_until_count(int i, int j, int cnt) {
    while (cnt--) move(i, j);
}
bool move_until_meet(int i, int j, int clr) {
    while (!A[i].empty() && A[i].back() != clr) move(i, j);
    return !A[i].empty();
}

int clr_count(int i, int c) {
    int cnt = 0;
    for (int j = 0; j < m; j++) cnt += A[i][j] == c;
    return cnt;
}
int construct_no_c(int c) {
    int u = -1, v = -1; // column 1, column 2
    for (int i = 1; i <= n + 1; i++) if (stat[i] == 0) { u = i; break; }
    for (int i = u + 1; i <= n + 1; i++) if (stat[i] == 0) { v = i; break; }

    move_until_count(v, emp, clr_count(u, c));
    while (!A[u].empty())
        if (back(u) == c) move(u, v);
        else move(u, emp);
    
    move_until_count(v, u, clr_count(emp, c));
    while (!A[emp].empty())
        if (back(emp) == c) move(emp, v);
        else move(emp, u);
    
    move_until_meet(u, emp, c);
    while (!A[v].empty())
        if (back(v) == c || A[emp].size() == m) move(v, u);
        else move(v, emp);
    
    swap(emp, v);
    stat[v] = 0; stat[emp] = -1;
    return v;
}

int main() {
    freopen("ball.in", "r", stdin);
    freopen("ball.out", "w", stdout);
    scanf("%d%d", &n, &m);
    for (int i = 1; i <= n; i++) {
        A[i].resize(m);
        for (int j = 0; j < m; j++) scanf("%d", &A[i][j]);
    }
    stat[n + 1] = -1; emp = n + 1;

    for (int c = 1; c < n; c++) {
        // construct no c
        int qaq = construct_no_c(c);
        // printf("construct_no_c %d success!\n", c);
        // solve
        for (int i = 1; i <= n + 1; i++) if (stat[i] == 0 && i != qaq) {
            move_until_count(qaq, emp, clr_count(i, c));
            while (!A[i].empty())
                if (back(i) == c) move(i, qaq);
                else move(i, emp);
            assert(A[qaq].size() == m);
            assert(A[emp].size() == m);
            qaq = emp;
            stat[emp] = 0; emp = i; stat[i] = -1;
        }
        for (int i = 1; i <= n + 1; i++) if (stat[i] == 0 && i != qaq) {
            assert(A[i].size() == m);
            int cnt = 0;
            while (back(i) == c) move(i, emp), cnt++;
            while (cnt--) move(qaq, i);
        }
        stat[emp] = 1; emp = qaq; stat[emp] = -1;
    }

    for (int i = 1; i <= n + 1; i++) if (i != emp) {
        for (int j = 1; j < m; j++)
            assert(A[i][j] == A[i][j - 1]);
    }
    printf("%d\n", ans.size());
    for (auto e : ans) printf("%d %d\n", e.first, e.second);
}
```

