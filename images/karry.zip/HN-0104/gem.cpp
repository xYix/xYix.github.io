#include<bits/stdc++.h>
#define pii pair<int , int>
#define fi first
#define se second
using namespace std;
int read() {
	char ch='!'; int res=0, f=0; while(!isdigit(ch)) { ch=getchar(); if(ch == '-') f=1; }
	while(isdigit(ch)) res=res*10+ch-'0', ch=getchar(); return f ? -res : res;
}

const int N=2e5+100;
int n, m, c, Q, p[N], fp[N], col[N], las[N], st[N], ans[N], f[N][19], g[N][19];
vector< pii > vec[N];
int head[N], ce, fa[N][19], dep[N]; struct edge{ int to, nxt; } e[N << 1];
void lnk(int a, int b) { e[++ce]=(edge){b, head[a]}, head[a]=ce; }

void dfs(int u, int lst) {
	int tmp=las[col[u]]; las[col[u]]=u;
	st[u]=las[p[1]], dep[u]=dep[lst]+1;
	if(fp[col[u]]) {
		f[u][0]=las[p[fp[col[u]]+1]], g[u][0]=las[p[fp[col[u]]-1]];
		for(int i=1;i <= 18;++i) f[u][i]=f[f[u][i-1]][i-1], g[u][i]=g[g[u][i-1]][i-1];
	}
	fa[u][0]=lst;
	for(int i=1;i <= 18;++i) fa[u][i]=fa[fa[u][i-1]][i-1];
	for(int i=head[u];i;i=e[i].nxt) { int v=e[i].to; if(v == lst) continue; dfs(v, u); }
	las[col[u]]=tmp;
}
int LCA(int x, int y) {
	if(dep[x] < dep[y]) swap(x, y);
	int d=dep[x]-dep[y], c=0;
	while(d) {if(d & 1) x=fa[x][c]; ++c, d >>= 1;}
	if(x == y) return x;
	for(int i=18;~i;--i) if(fa[x][i] != fa[y][i]) x=fa[x][i], y=fa[y][i];
	return fa[x][0];
}
int jump(int o, int x, int y) {
	if(dep[x] < dep[y]) return 0;
	int res=1;
	for(int i=18;~i;--i)
		if(o) {if(dep[g[x][i]] >= dep[y]) x=g[x][i], res += (1 << i); }
		else {if(dep[f[x][i]] >= dep[y]) x=f[x][i], res += (1 << i); }
	return res;
}
void solve(int u, int lst) {
	int tmp=las[col[u]]; las[col[u]]=u;
	for(int i=0;i < vec[u].size();++i) {
		pii t=vec[u][i];
		int x=t.fi, y=u, z=LCA(x, y), Len1=jump(0, st[x], z);
		int l=Len1, r=c+1, mid;
		while(l < r-1) {
			mid=(l+r) >> 1;
			jump(1, las[p[mid]], z)+Len1 >= mid ? l=mid : r=mid;
		}
		ans[t.se]=l;
	}
	for(int i=head[u];i;i=e[i].nxt) {
		int v=e[i].to; if(v == lst) continue;
		solve(v, u);
	}
	las[col[u]]=tmp;	
}

int main() {
	freopen("gem.in", "r", stdin);
	freopen("gem.out", "w", stdout);
	n=read(), m=read(), c=read();
	for(int i=1;i <= c;++i) p[i]=read(), fp[p[i]]=i;
	for(int i=1;i <= n;++i) col[i]=read();
	for(int i=1;i < n;++i) {
		int x=read(), y=read();
		lnk(x, y), lnk(y, x);
	}
	dfs(1, 0); Q=read();
	//for(int i=1;i <= m;++i) cout << las[i] <<" "; puts("");
	for(int i=1;i <= Q;++i) { int s=read(), t=read(); vec[t].push_back(pii(s, i)); }
	solve(1, 0);
	for(int i=1;i <= Q;++i) printf("%d\n", ans[i]);
	return 0;
}
