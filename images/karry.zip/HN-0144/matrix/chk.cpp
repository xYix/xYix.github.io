#include<bits/stdc++.h>
using namespace std;
FILE *in,*out,*ans;
int a[305][305],b[305][305];
char s[305];
int main(){
	in=fopen("matrix.in","r");
	out=fopen("matrix.out","r");
	ans=fopen("matrix.ans","r");
	int t;
	fscanf(in,"%d",&t);
	for(;t;--t){
		int n,m;
		fscanf(in,"%d%d",&n,&m);
		for(int i=2;i<=n;++i)for(int j=2;j<=m;++j)fscanf(in,"%d",a[i]+j);
		int v;
		fscanf(out,"%s",s);
		fscanf(ans,"%d",&v);
		assert(!v || s[0]=='Y');
		if(s[0]=='Y'){
			for(int i=1;i<=n;++i)for(int j=1;j<=m;++j)fscanf(out,"%d",b[i]+j);
			for(int i=2;i<=n;++i)for(int j=2;j<=m;++j)assert(a[i][j]==b[i][j]+b[i-1][j]+b[i][j-1]+b[i-1][j-1]);
			for(int i=2;i<=n;++i)for(int j=2;j<=m;++j)assert(0<=b[i][j]);
			for(int i=2;i<=n;++i)for(int j=2;j<=m;++j)assert(b[i][j]<=1000000);
			printf("Correct.\n");
		}
	}
	return 0;
}
