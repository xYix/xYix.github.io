#include<bits/stdc++.h>
#define int long long
using namespace std;
void read(int &a){
	char ch;
	while(!isdigit(ch=getchar()));
	a=0;
	for(;isdigit(ch);ch=getchar()){a=a*10+ch-'0';}
}
bool chkmin(int &a,int b){return a>b?a=b,1:0;}
bool chkmax(int &a,int b){return a<b?a=b,1:0;}
typedef pair<int,int> pii;
#define x first
#define y second
int a[305][305],b[305][305];
const int inf=0x3f3f3f3f3f3f3f3f;
int w[305][305];
int d[305];
const int lim=1000000;
namespace run{
	bool main(){
		int n,m;
		read(n);read(m);
		for(int i=1;i<=n;++i)for(int j=1;j<=m;++j)a[i][j]=0;
		for(int i=2;i<=n;++i){
			for(int j=2;j<=m;++j){
				read(a[i][j]);
				b[i][j]=a[i][j];
			}
		}
		for(int i=1;i<m;++i)for(int j=i+1;j<=m;++j){
			if(!((i^j)&1)){
				w[i][j]=w[j][i]=lim;
			}
			else{
				if(i&1){
					w[i][j]=lim+lim;
					w[j][i]=0;
				}
				else{
					w[j][i]=lim+lim;
					w[i][j]=0;
				}
			}
		}

		for(int i=2;i<=n;++i){
			for(int j=2;j<=m;++j){
				a[i][j]=(j&1?-a[i][j]:a[i][j])+a[i][j-1];
			}	
			for(int j=1;j<=m;++j)a[i][j]-=a[i-1][j];
			if(i&1){
				for(int j=1;j<m;++j)for(int k=j+1;k<=m;++k){
					if(!((j^k)&1)){
						chkmin(w[j][k],lim+a[i][j]-a[i][k]);
						chkmin(w[k][j],lim+a[i][k]-a[i][j]);
					}	
					else{
						if(j&1){
							chkmin(w[j][k],lim+lim+a[i][j]-a[i][k]);
							chkmin(w[k][j],a[i][k]-a[i][j]);
						}	
						else{
							chkmin(w[j][k],a[i][j]-a[i][k]);
							chkmin(w[k][j],lim+lim+a[i][k]-a[i][j]);
						}
					}
				}
				// a[i][j]+x
			}
			else{
				for(int j=1;j<m;++j)for(int k=j+1;k<=m;++k){
					if(!((j^k)&1)){
						chkmin(w[k][j],lim+a[i][j]-a[i][k]);
						chkmin(w[j][k],lim+a[i][k]-a[i][j]);
					}	
					else{
						if(j&1){
							chkmin(w[k][j],lim+lim+a[i][j]-a[i][k]);
							chkmin(w[j][k],a[i][k]-a[i][j]);
						}	
						else{
							chkmin(w[k][j],a[i][j]-a[i][k]);
							chkmin(w[j][k],lim+lim+a[i][k]-a[i][j]);
						}
					}
				}
				//a[i][j]-x
			}
		}
		for(int i=1;i<=m;++i)d[i]=inf;
		d[1]=0;
		for(int k=1;k<n;++k)for(int i=1;i<=m;++i)for(int j=1;j<=m;++j)chkmin(d[j],d[i]+w[i][j]);
		for(int i=1;i<=m;++i)for(int j=1;j<=m;++j)if(chkmin(d[j],d[i]+w[i][j])){printf("NO\n");return 0;}
		printf("YES\n");
		for(int i=2;i<=m;++i){
			a[1][i]=d[i]-d[i-1];
			if(i&1)a[1][i]=-a[1][i];
		}
		for(int i=2;i<=n;++i)for(int j=2;j<=m;++j)a[i][j]=b[i][j]-a[i-1][j];

		for(int i=1;i<=n;++i){
			int xl=0,xr=lim;
			int w=0;
			for(int j=2;j<=m;++j){
				w=a[i][j]-w;
				if(j&1){
					chkmin(xr,lim-w);
					chkmax(xl,-w);
				}
				else{
					chkmin(xr,w);
					chkmax(xl,w-lim);
				}
			}
			a[i][1]=xl;
			for(int j=2;j<=m;++j)a[i][j]-=a[i][j-1];
		}
		for(int i=1;i<=n;++i)for(int j=1;j<=m;++j)printf("%lld%c",a[i][j],j==m?'\n':' ');
	}
}
signed main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	int t;
	read(t);
	for(;t;--t){
		run::main();
	}
	return 0;
}
