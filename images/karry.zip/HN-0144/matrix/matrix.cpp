#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
void read(int &a){
	char ch;
	while(!isdigit(ch=getchar()));
	a=0;
	for(;isdigit(ch);ch=getchar()){a=a*10+ch-'0';}
}
void read(ll &a){
	char ch;
	while(!isdigit(ch=getchar()));
	a=0;
	for(;isdigit(ch);ch=getchar()){a=a*10+ch-'0';}
}

char itg[55];
void write(int a){
	char ch;
	int t=0;
	do{itg[++t]=a%10+'0';a/=10;}while(a);
	for(;t;--t)putchar(itg[t]);
}
template<class T,class T2>bool chkmin(T &a,T2 b){return a>b?a=b,1:0;}
template<class T,class T2>bool chkmax(T &a,T2 b){return a<b?a=b,1:0;}
typedef pair<int,int> pii;
#define x first
#define y second
int a[305][305],ra[305][305];
int b[305][305];
int na[305];
const int inf=0x3f3f3f3f;
int w[305][305];
int d[305];
const int lim=1000000,nlim=lim+lim,lim3=lim+nlim;
namespace run{
	bool main(){
		int n,m;
		read(n);read(m);
		for(int i=1;i<=n;++i)for(int j=1;j<=m;++j)a[i][j]=0;
		for(int i=2;i<=n;++i){
			for(int j=2;j<=m;++j){
				read(a[i][j]);
				b[i][j]=a[i][j];
			}
		}
		/*for(int i=1;i<m;++i)for(int j=i+1;j<=m;++j){
			if(!((i^j)&1)){
				w[i][j]=w[j][i]=lim;
			}
			else{
				if(i&1){
					w[i][j]=lim+lim;
					w[j][i]=0;
				}
				else{
					w[j][i]=lim+lim;
					w[i][j]=0;
				}
			}
		}*/
		for(int i=1;i<=m;++i)ra[i][1]=0;
		for(int i=2;i<=n;++i){
			for(int j=2;j<=m;++j){
				a[i][j]=(j&1?-a[i][j]:a[i][j])+a[i][j-1];
			}	
			for(int j=1;j<=m;++j)a[i][j]-=a[i-1][j];
			for(int j=1;j<=m;++j){
				if(abs(a[i][j])>lim3 && abs(a[i][j]-a[i][2])>lim3)return printf("NO\n");
			}
			for(int j=1;j<=m;++j)ra[j][i]=i&1?a[i][j]:-a[i][j];
			//for(int j=1;j<=m;++j)if(abs(ra[j][i])>lim3){return printf("NO\n");}
			/*if(i&1){
				for(int j=1;j<m;++j)for(int k=j+1;k<=m;++k){
					if(!((j^k)&1)){
						chkmin(w[j][k],lim+na[j]-na[k]);
						chkmin(w[k][j],lim+na[k]-na[j]);
					}	
					else{
						if(j&1){
							chkmin(w[j][k],lim+lim+na[j]-na[k]);
							chkmin(w[k][j],na[k]-na[j]);
						}	
						else{
							chkmin(w[j][k],na[j]-na[k]);
							chkmin(w[k][j],lim+lim+na[k]-na[j]);
						}
					}
				}
				// na[j]+x
			}
			else{
				for(int j=1;j<m;++j)for(int k=j+1;k<=m;++k){
					if(!((j^k)&1)){
						chkmin(w[k][j],lim+na[j]-na[k]);
						chkmin(w[j][k],lim+na[k]-na[j]);
					}	
					else{
						if(j&1){
							chkmin(w[k][j],lim+lim+na[j]-na[k]);
							chkmin(w[j][k],na[k]-na[j]);
						}	
						else{
							chkmin(w[k][j],na[j]-na[k]);
							chkmin(w[j][k],lim+lim+na[k]-na[j]);
						}
					}
				}
				//a[i][j]-x
			}*/
		}
		for(int i=1;i<m;++i)for(int j=i+1;j<=m;++j)
			if(!((i^j)&1)){
				w[i][j]=0;
				for(int k=1;k<=n;++k)chkmin(w[i][j],ra[i][k]-ra[j][k]);
				w[i][j]+=lim;
				w[j][i]=0;
				for(int k=1;k<=n;++k)chkmin(w[j][i],ra[j][k]-ra[i][k]);
				w[j][i]+=lim;
				if(w[i][j]<-nlim || w[j][i]<-nlim){return printf("NO\n");}
				//a[k][i]-a[k][j]);
			}
			else{
				w[i][j]=w[j][i]=lim+lim;
				if(i&1){
					for(int k=1;k<=n;k+=2)chkmin(w[j][i],ra[j][k]-ra[i][k]);
					for(int k=2;k<=n;k+=2)chkmin(w[i][j],ra[i][k]-ra[j][k]);
					for(int k=2;k<=n;k+=2)chkmin(w[j][i],ra[j][k]-ra[i][k]+lim+lim);
					for(int k=1;k<=n;k+=2)chkmin(w[i][j],ra[i][k]-ra[j][k]+lim+lim);
				}
				else{
					for(int k=2;k<=n;k+=2)chkmin(w[j][i],ra[j][k]-ra[i][k]);
					for(int k=1;k<=n;k+=2)chkmin(w[i][j],ra[i][k]-ra[j][k]);
					for(int k=1;k<=n;k+=2)chkmin(w[j][i],ra[j][k]-ra[i][k]+lim+lim);
					for(int k=2;k<=n;k+=2)chkmin(w[i][j],ra[i][k]-ra[j][k]+lim+lim);
				}
				if(w[i][j]<-nlim || w[j][i]<-nlim){return printf("NO\n");}
			}

		for(int i=1;i<=m;++i)d[i]=inf;
		d[1]=0;
		for(int k=1;k<m;++k){
			bool ok=0;
			for(int i=1;i<=m;++i){for(int j=1;j<=m;++j)if(chkmin(d[j],d[i]+w[i][j]))ok=1;}
			for(int i=1;i<=m;++i)if(d[i]<-inf){printf("NO\n");return 0;}
			//if(!ok)break;
		}
		for(int i=1;i<=m;++i)for(int j=1;j<=m;++j)if(chkmin(d[j],d[i]+w[i][j])){printf("NO\n");return 0;}
		for(int i=2;i<=m;++i){
			a[1][i]=d[i]-d[i-1];
			if(i&1)a[1][i]=-a[1][i];
		}
		for(int i=2;i<=n;++i)for(int j=2;j<=m;++j)a[i][j]=b[i][j]-a[i-1][j];

		for(int i=1;i<=n;++i){
			int xl=0,xr=lim;
			int w=0;
			for(int j=2;j<=m;++j){
				w=a[i][j]-w;
				if(j&1){
					chkmin(xr,lim-w);
					chkmax(xl,-w);
				}
				else{
					chkmin(xr,w);
					chkmax(xl,w-lim);
				}
			}
			a[i][1]=xl;
			for(int j=2;j<=m;++j)a[i][j]-=a[i][j-1];
		}
		for(int i=1;i<=n;++i)for(int j=1;j<=m;++j)if(a[i][j]>lim || a[i][j]<0)return printf("NO\n");
		for(int i=2;i<=n;++i)for(int j=2;j<=m;++j){
			if(a[i][j]+a[i-1][j]+a[i][j-1]+a[i-1][j-1]!=b[i][j])return printf("NO\n");
		}
		printf("YES\n");
		for(int i=1;i<=n;++i)for(int j=1;j<=m;++j){
			write(a[i][j]);
			putchar(j==m?'\n':' ');
		}
	}
}
signed main(){
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	int t;
	read(t);
	for(;t;--t){
		run::main();
	}
	return 0;
}
