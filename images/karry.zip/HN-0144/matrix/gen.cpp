#include<bits/stdc++.h>
using namespace std;
random_device rnd;
int a[305][305];
int main(){
	freopen("matrix.in","w",stdout);
	printf("10\n");
	int n,m;	
	for(int c=1;c<=10;++c){
		int lim=300;
		n=rnd()%(lim-1)+2,m=rnd()%(lim-1)+2;
		n=lim;m=lim;
		printf("%d %d\n",n,m);
		for(int i=1;i<=n;++i){
			for(int j=1;j<=m;++j)a[i][j]=rnd()%1000001;
		}	
		for(int i=2;i<=n;++i)for(int j=2;j<=m;++j)printf("%d%c",a[i][j]+a[i-1][j]+a[i][j-1]+a[i-1][j-1],j==m?'\n':' ');
	}
	return 0;
}
