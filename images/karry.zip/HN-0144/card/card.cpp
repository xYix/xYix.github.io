#include<bits/stdc++.h>
using namespace std;
void read(int &a){
	char ch;
	while(!isdigit(ch=getchar()));
	a=0;
	for(;isdigit(ch);ch=getchar()){a=a*10+ch-'0';}
}
typedef pair<int,int> pii;
#define x first
#define y second
pii a[2000005];
bool chkmin(int &a,int b){return a>b?a=b,1:0;}
int s[4];
int w[1000005];
void flip(int x){
	int y=x&1;x>>=1;	
	--s[w[x]];++s[w[x]^=1<<y];
}
int main(){
	freopen("card.in","r",stdin);
	freopen("card.out","w",stdout);
	int n,m;
	read(n);read(m);
	for(int i=1;i<=n;++i){
		read(a[i].x);	
		a[i].y=i<<1;
	}
	for(int i=1;i<=n;++i){
		read(a[i+n].x);	
		a[i+n].y=i<<1|1;
	}
	s[0]=n;
	sort(a+1,a+n+n+1);
	int ans=0x3f3f3f3f;
	for(int i=1,j=0;i<=n+n;++i){
		while(j<n+n && (s[0] || s[2]>m)){
			flip(a[++j].y);
		}
		if(s[2]<=m && !s[0]){chkmin(ans,a[j].x-a[i].x);}
		flip(a[i].y);	
	}
	printf("%d\n",ans);
	return 0;
}
