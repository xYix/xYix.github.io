#include<bits/stdc++.h>
using namespace std;
typedef int ll;
typedef long long int li;
const ll MAXN=3e6+51;
struct Item{
	ll id,typ,val;
	inline bool operator <(const Item &rhs)const;
};
Item it[MAXN];
ll n,m,ptr,res;
ll x[MAXN],y[MAXN],r[MAXN],d[4];
inline ll read()
{
	register int num=0,neg=1;
	register char ch=getchar();
	while(!isdigit(ch)&&ch!='-')
	{
		ch=getchar();
	}
	if(ch=='-')
	{
		neg=-1;
		ch=getchar();
	}
	while(isdigit(ch))
	{
		num=(num<<3)+(num<<1)+(ch-'0');
		ch=getchar();
	}
	return num*neg;
}
inline bool Item::operator <(const Item &rhs)const
{
	return val<rhs.val;
}
inline void change(ll x)
{
	d[r[it[x].id]]--,d[r[it[x].id]^=(1<<it[x].typ)]++;
}
int main()
{
	freopen("card.in","r",stdin);
	freopen("card.out","w",stdout);
	n=read(),m=read(),ptr=1,res=2e9;
	for(register int i=1;i<=n;i++)
	{
		it[i]=(Item){i,0,x[i]=read()};
	}
	for(register int i=1;i<=n;i++)
	{
		it[n+i]=(Item){i,1,y[i]=read()};
	}
	sort(it+1,it+2*n+1),d[0]=n;
	for(register int i=1;i<=2*n;i++)
	{
		while(ptr<=2*n&&(d[0]||d[2]>m))
		{
			change(ptr++);
		}
		!d[0]&&d[2]<=m?res=min(res,it[ptr-1].val-it[i].val):1,change(i);
	}
	printf("%d\n",res);
}
