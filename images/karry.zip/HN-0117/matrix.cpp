#include<bits/stdc++.h>
using namespace std;
typedef int ll;
typedef long long int li;
const ll MAXN=451;
ll test,n,m,limit,ccc,cpp;
ll r[MAXN][MAXN],rrr[MAXN][MAXN],d[MAXN][MAXN],res[MAXN][MAXN];
li syk[MAXN];
inline ll read()
{
	register int num=0,neg=1;
	register char ch=getchar();
	while(!isdigit(ch)&&ch!='-')
	{
		ch=getchar();
	}
	if(ch=='-')
	{
		neg=-1;
		ch=getchar();
	}
	while(isdigit(ch))
	{
		num=(num<<3)+(num<<1)+(ch-'0');
		ch=getchar();
	}
	return num*neg;
}
inline void calc(ll x)
{
	ll u,v;
	for(register int i=1;i<=m;i++)
	{
		for(register int j=i+1;j<=m;j++)
		{
			u=j,v=i,(x&1)?swap(u,v):(void)1;
			if((i&1)==(j&1))
			{
				d[u][v]=min(d[u][v],limit+r[x][i]-r[x][j]);
				d[v][u]=min(d[v][u],limit+r[x][j]-r[x][i]);
				continue;
			}
			if(i&1)
			{
				d[u][v]=min(d[u][v],limit*2+r[x][i]-r[x][j]);
				d[v][u]=min(d[v][u],r[x][j]-r[x][i]);
				continue;
			}
			d[u][v]=min(d[u][v],r[x][i]-r[x][j]);
			d[v][u]=min(d[v][u],limit*2+r[x][j]-r[x][i]);
		}
	}
}
inline void solve()
{
	n=read(),m=read(),memset(d,0,sizeof(d)),memset(syk,0x3f,sizeof(syk)),syk[1]=0;
	for(register int i=2;i<=n;i++)
	{
		for(register int j=2;j<=m;j++)
		{
			rrr[i][j]=r[i][j]=read();
		}
	}
	for(register int i=2;i<=n;i++)
	{
		for(register int j=2;j<=m;j++)
		{
			r[i][j]=r[i][j-1]+(j&1?-r[i][j]:r[i][j]);
		}
	}
	for(register int i=1;i<=m;i++)
	{
		for(register int j=i+1;j<=m;j++)
		{
			(i&1)==(j&1)?d[i][j]=d[j][i]=1e6:(i&1)?d[i][j]=2e6:d[j][i]=2e6;
		}
	}
	for(register int i=2;i<=n;i++)
	{
		for(register int j=2;j<=m;j++)
		{
			r[i][j]-=r[i-1][j];
		}
	}
	for(register int i=2;i<=n;i++)
	{
		calc(i);
	}
	for(register int i=1;i<=n-1;i++)
	{
		for(register int j=1;j<=m;j++)
		{
			for(register int k=1;k<=m;k++)
			{
				syk[k]=min(syk[k],syk[j]+d[j][k]);
			}
		}
	}
	for(register int i=1;i<=m;i++)
	{
		for(register int j=1;j<=m;j++)
		{
			if(syk[j]>syk[i]+d[i][j])
			{
				return (void)puts("NO");
			}
		}
	}
	puts("YES"),memset(res,0,sizeof(res)),memset(r,0,sizeof(r));
	for(register int i=2;i<=m;i++)
	{
		r[1][i]=(i&1)?syk[i-1]-syk[i]:syk[i]-syk[i-1];
	}
	for(register int i=2;i<=n;i++)
	{
		for(register int j=2;j<=m;j++)
		{
			r[i][j]=rrr[i][j]-r[i-1][j];
		}
	}
	for(register int i=1;i<=n;i++)
	{
		ccc=0,cpp=0;
		for(register int j=2;j<=m;j++)
		{
			ccc=r[i][j]-ccc,cpp=max(cpp,(j&1)?-ccc:ccc-limit);
		}
		r[i][1]=cpp;
		for(register int j=2;j<=m;j++)
		{
			r[i][j]-=r[i][j-1];
		}
	}
	for(register int i=1;i<=n;i++)
	{
		for(register int j=1;j<=m;j++)
		{
			printf("%d ",r[i][j]);
		}
		puts("");
	}
	memset(r,0,sizeof(r)),memset(rrr,0,sizeof(rrr)),memset(d,0,sizeof(d));
}
int main()
{
	freopen("matrix.in","r",stdin);
	freopen("matrix.out","w",stdout);
	test=read(),limit=1e6;
	for(register int i=0;i<test;i++)
	{
		solve();
	}
}
