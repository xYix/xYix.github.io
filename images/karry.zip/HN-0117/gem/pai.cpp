#include<bits/stdc++.h>
using namespace std;
typedef int ll;
typedef long long int li;
const ll MAXN=2e5+51;
inline ll read()
{
	register ll num=0,neg=1;
	register char ch=getchar();
	while(!isdigit(ch)&&ch!='-')
	{
		ch=getchar();
	}
	if(ch=='-')
	{
		neg=-1;
		ch=getchar();
	}
	while(isdigit(ch))
	{
		num=(num<<3)+(num<<1)+(ch-'0');
		ch=getchar();
	}
	return num*neg;
}
int main()
{
	ll test=0;
	while(++test)
	{
		system("./maker"),system("./bf"),system("./gem");
		if(system("diff -Bb bf.out gem.out"))
		{
			return printf("Wrong Answer on test %d\n",test),0;
		}
		printf("Running on test %d\n",test);
	}
}
