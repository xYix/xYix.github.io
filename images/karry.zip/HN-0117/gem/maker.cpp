#include<bits/stdc++.h>
using namespace std;
typedef int ll;
typedef long long int li;
const ll MAXN=2e5+51;
ll n,m,c,qcnt;
ll p[MAXN],fa[MAXN];
inline ll read()
{
	register ll num=0,neg=1;
	register char ch=getchar();
	while(!isdigit(ch)&&ch!='-')
	{
		ch=getchar();
	}
	if(ch=='-')
	{
		neg=-1;
		ch=getchar();
	}
	while(isdigit(ch))
	{
		num=(num<<3)+(num<<1)+(ch-'0');
		ch=getchar();
	}
	return num*neg;
}
int main()
{
	freopen("gem.in","w",stdout);
	srand(time(0));
	n=1000,m=15,qcnt=1000,c=rand()%m+1,printf("%d %d %d\n",n,m,c);
	for(register int i=1;i<=m;i++)
	{
		p[i]=i;
	}
	random_shuffle(p+1,p+m+1);
	for(register int i=1;i<=c;i++)
	{
		printf("%d ",p[i]);
	}
	puts("");
	for(register int i=1;i<=n;i++)
	{
		printf("%d ",rand()%m+1);
	}
	puts("");
	for(register int i=2;i<=n;i++)
	{
		printf("%d %d\n",i,rand()%(i-1)+1);
	}
	printf("%d\n",qcnt);
	for(register int i=1;i<=qcnt;i++)
	{
		ll u=rand()%n+1,v=rand()%n+1;
		printf("%d %d\n",u,v);
	}
}
