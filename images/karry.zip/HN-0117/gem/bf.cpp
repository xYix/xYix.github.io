#include<bits/stdc++.h>
using namespace std;
typedef int ll;
typedef long long int li;
const ll MAXN=2e5+51;
struct Edge{
	ll to,prev;
};
Edge ed[MAXN<<1];
ll n,m,c,qcnt,tot,u,v;
ll last[MAXN],x[MAXN],w[MAXN],d[MAXN];
inline ll read()
{
	register ll num=0,neg=1;
	register char ch=getchar();
	while(!isdigit(ch)&&ch!='-')
	{
		ch=getchar();
	}
	if(ch=='-')
	{
		neg=-1;
		ch=getchar();
	}
	while(isdigit(ch))
	{
		num=(num<<3)+(num<<1)+(ch-'0');
		ch=getchar();
	}
	return num*neg;
}
inline void addEdge(ll u,ll v)
{
	ed[++tot]=(Edge){v,last[u]},last[u]=tot;
}
inline void dfs(ll node,ll fa)
{
	d[node]=d[fa]+(x[d[fa]+1]==w[node]);
	for(register int i=last[node];i;i=ed[i].prev)
	{
		ed[i].to!=fa?dfs(ed[i].to,node):(void)1;
	}
}
int main()
{
	freopen("gem.in","r",stdin);
	freopen("bf.out","w",stdout);
	n=read(),m=read(),c=read();
	for(register int i=1;i<=c;i++)
	{
		x[i]=read();
	}
	for(register int i=1;i<=n;i++)
	{
		w[i]=read();
	}
	for(register int i=1;i<=n-1;i++)
	{
		u=read(),v=read(),addEdge(u,v),addEdge(v,u);
	}
	qcnt=read();
	for(register int i=1;i<=qcnt;i++)
	{
		u=read(),v=read(),dfs(u,0),printf("%d\n",d[v]);
	}
}
