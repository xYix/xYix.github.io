#include<bits/stdc++.h>
using namespace std;
typedef int ll;
typedef long long int li;
const ll MAXN=2e5+51;
struct Edge{
	ll to,prev;
};
struct Query{
	ll u,id;
};
Edge ed[MAXN<<1];
ll n,m,c,qcnt,tot,u,v;
ll last[MAXN],x[MAXN],w[MAXN],rp[MAXN],depth[MAXN],lst[MAXN];
ll f[MAXN][19],g[MAXN][19],anc[MAXN][19],d[MAXN],res[MAXN];
vector<Query>qry[MAXN];
inline ll read()
{
	register ll num=0,neg=1;
	register char ch=getchar();
	while(!isdigit(ch)&&ch!='-')
	{
		ch=getchar();
	}
	if(ch=='-')
	{
		neg=-1;
		ch=getchar();
	}
	while(isdigit(ch))
	{
		num=(num<<3)+(num<<1)+(ch-'0');
		ch=getchar();
	}
	return num*neg;
}
inline void addEdge(ll u,ll v)
{
	ed[++tot]=(Edge){v,last[u]},last[u]=tot;
}
inline void dfs(ll node,ll fa)
{
	ll r=lst[w[node]];
	lst[w[node]]=node,d[node]=lst[x[1]],depth[node]=depth[fa]+1;
	if(rp[w[node]])
	{
		f[node][0]=lst[x[rp[w[node]]+1]],g[node][0]=lst[x[rp[w[node]]-1]];
		for(register int i=1;i<=18;i++)
		{
			f[node][i]=f[f[node][i-1]][i-1];
			g[node][i]=g[g[node][i-1]][i-1];
			anc[node][i]=anc[anc[node][i-1]][i-1];
		}
	}
	anc[node][0]=fa;
	for(register int i=1;i<=18;i++)
	{
		anc[node][i]=anc[anc[node][i-1]][i-1];
	}
	for(register int i=last[node];i;i=ed[i].prev)
	{
		ed[i].to!=fa?dfs(ed[i].to,node):(void)1;
	}
	lst[w[node]]=r;
}
inline ll jumpF(ll x,ll y)
{
	if(depth[x]<depth[y])
	{
		return 0;
	}
	ll res=1;
	for(register int i=18;i>=0;i--)
	{
		depth[f[x][i]]>=depth[y]?x=f[x][i],res+=(1<<i):1;
	}
	return res;
}
inline ll jumpG(ll x,ll y)
{
	if(depth[x]<depth[y])
	{
		return 0;
	}
	ll res=1;
	for(register int i=18;i>=0;i--)
	{
		depth[g[x][i]]>=depth[y]?x=g[x][i],res+=(1<<i):1;
	}
	return res;
}
inline ll LCA(ll x,ll y)
{
	depth[x]<depth[y]?swap(x,y):(void)1;
	for(register int i=18;i>=0;i--)
	{
		depth[anc[x][i]]>=depth[y]?x=anc[x][i]:1;
	}
	for(register int i=18;i>=0;i--)
	{
		anc[x][i]!=anc[y][i]?x=anc[x][i],y=anc[y][i]:1;
	}
	return x==y?x:anc[x][0];
}
namespace Subtask2{
	ll totn;
	ll ls[10051],rs[10051],sm[10051],rt[1051],rt2[1051];
	inline ll insert(ll l,ll r,ll pos,ll val,ll node)
	{
		ll cur=++totn;
		ls[cur]=ls[node],rs[cur]=rs[node],sm[cur]=sm[node];
		if(l==r)
		{
			return sm[cur]=val,cur;
		}
		ll mid=(l+r)>>1;
		pos<=mid?ls[cur]=insert(l,mid,pos,val,ls[node]):1;
		pos>mid?rs[cur]=insert(mid+1,r,pos,val,rs[node]):1;
		return cur;
	}
	inline ll query(ll l,ll r,ll pos,ll node)
	{
		if(pos<l||pos>r)
		{
			return 0;
		}
		if(l==r)
		{
			return sm[node];
		}
		ll mid=(l+r)>>1;
		return pos<=mid?query(l,mid,pos,ls[node]):query(mid+1,r,pos,rs[node]);
	}
	inline ll query(ll u,ll pos)
	{
		if(!u)
		{
			return 0;
		}
		ll l=1,r=pos,mid,res=pos+1;
		while(l<=r)
		{
			mid=(l+r)>>1;
			mid+query(1,c,mid,rt[u])-1>=pos?r=mid-1,res=mid:l=mid+1;
		}
		return pos-res+1;
	}
}
inline void dfs2(ll node,ll fa)
{
	ll rr=lst[w[node]],u,v,lx,len,l,r,mid;
	lst[w[node]]=node;
	for(register int i=0;i<qry[node].size();i++)
	{
		u=qry[node][i].u,v=node;
		lx=LCA(u,v),len=l=jumpF(d[u],lx),r=n+1;
		while(l<r-1)
		{
			mid=(l+r)>>1;
			jumpG(lst[x[mid]],lx)+len>=mid?l=mid:r=mid;
		}
		res[qry[node][i].id]=l;
	}
	for(register int i=last[node];i;i=ed[i].prev)
	{
		ed[i].to!=fa?dfs2(ed[i].to,node):(void)1;
	}
	lst[w[node]]=rr;
}
namespace Subtask1{
	inline void dfs(ll node,ll fa)
	{
		d[node]=d[fa]+(x[d[fa]+1]==w[node]);
		for(register int i=last[node];i;i=ed[i].prev)
		{
			ed[i].to!=fa?dfs(ed[i].to,node):(void)1;
		}
	}
	inline void main()
	{
		for(register int i=1;i<=qcnt;i++)
		{
			u=read(),v=read(),dfs(u,0),printf("%d\n",d[v]);
		}
	}
}
int main()
{
	freopen("gem.in","r",stdin);
	freopen("gem.out","w",stdout);
	n=read(),m=read(),c=read();
	for(register int i=1;i<=c;i++)
	{
		x[i]=read(),rp[x[i]]=i;
	}
	for(register int i=1;i<=n;i++)
	{
		w[i]=read();
	}
	for(register int i=1;i<=n-1;i++)
	{
		u=read(),v=read(),addEdge(u,v),addEdge(v,u);
	}
	dfs(1,0),qcnt=read();
	for(register int i=1;i<=qcnt;i++)
	{
		u=read(),v=read(),qry[v].push_back((Query){u,i});
	}
	dfs2(1,0);
	for(register int i=1;i<=qcnt;i++)
	{
		printf("%d\n",res[i]);
	}
}
