#include<bits/stdc++.h>
using namespace std;

const int maxn = 1000005;
int n;
long long m;
vector<int> G[maxn];

int stk[maxn], len;
int DFN[maxn], LOW[maxn], idx;
bool qaq[maxn];
void Tarjan(int x, int fa) {
    // printf("vis %d\n", x);
    DFN[x] = LOW[x] = ++idx;
    stk[++len] = x;
    for (int y : G[x]) if (y != fa)
        if (!DFN[y]) {
            Tarjan(y, x), LOW[x] = min(LOW[x], LOW[y]);
            if (LOW[y] >= DFN[x]) {
                for (int i = len; stk[i + 1] != y; i--)
                    qaq[stk[i]] = 1;
                qaq[x] = 1;
                for (int i = len; stk[i + 1] != y; i--)
                for (int v : G[stk[i]])
                    if (qaq[v] && DFN[stk[i]] > DFN[v])
                        m--/*, printf("del %d %d\n", stk[i], v)*/;
                int cnt = 0;
                while (stk[len + 1] != y) cnt++, qaq[stk[len]] = 0, len--;
                qaq[x] = 0;
                // printf("check %d\n", cnt + 1);
                m += 1LL * cnt * (cnt + 1) / 2;
            }
        }
        else LOW[x] = min(LOW[x], DFN[y]);
    // printf("DFN[%d] = %d, LOW = %d\n", x, DFN[x], LOW[x]);
}

int main() {
    freopen("graph.in", "r", stdin);
    freopen("graph.out", "w", stdout);
    scanf("%d%lld", &n, &m);
    for (int i = 1; i <= m; i++) {
        int u, v; scanf("%d%d", &u, &v);
        G[u].push_back(v);
        G[v].push_back(u);
    }
    for (int x = 1; x <= n; x++) if (!DFN[x]) {
        Tarjan(x, 0);
        assert(len == 1);
        stk[len--];
    }
    printf("%lld\n", m);
}