#include<bits/stdc++.h>
using namespace std;
typedef unsigned long long ull;

const int maxn = 5000005;
char s[maxn]; int n, k;
int nxt[maxn];

const ull B = 131;
ull hsh[maxn], rhsh[maxn], thsh[maxn];

int main() {
    freopen("easy.in", "r", stdin);
    freopen("easy.out", "w", stdout);
    scanf("%s", s + 1); n = strlen(s + 1);
    scanf("%d", &k);

    ull qaq = 1;
    ull ans = 0;
    for (int i = 1; i <= n; i++) {
        if (i != 1) {
            s[i] = (thsh[i - 1] + s[i] - 'a') % 26 + 'a';
        }

        hsh[i] = B * B * hsh[i - 1] + B * (s[i] - 'a');
        rhsh[i] = rhsh[i - 1] + qaq * (s[i] - 'a');
        thsh[i] = hsh[i] + rhsh[i];
        qaq *= B * B;

        if (i != 1) {
            nxt[i] = nxt[i - 1];
            while (nxt[i] && s[nxt[i] + 1] != s[i]) nxt[i] = nxt[nxt[i]];
            if (s[nxt[i] + 1] == s[i]) nxt[i]++;
            thsh[i] += thsh[nxt[i]];
        }

        ans ^= thsh[i];
        if (i % k == 0)
            printf("%llu\n", ans), ans = 0;
    }
}