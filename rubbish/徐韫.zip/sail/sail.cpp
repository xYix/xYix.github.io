#include<bits/stdc++.h>
using namespace std;

const int p = 998244353;
struct Z {int x; Z(int x0 = 0) : x(x0) {}};
int inline check(int x) { return x >= p ? x - p : x; }
Z operator +(const Z a, const Z b) { return check(a.x + b.x); }
Z operator -(const Z a, const Z b) { return check(a.x - b.x + p); }
Z operator -(const Z a) {return check(p - a.x);}
Z operator *(const Z a, const Z b) { return 1LL * a.x * b.x % p; }
Z& operator +=(Z &a, const Z b) { return a = a + b; }
Z& operator -=(Z &a, const Z b) { return a = a - b; }
Z& operator *=(Z &a, const Z b) { return a = a * b; }
Z qpow(Z a, int k) {
	Z ans = 1;
	for (; k; a *= a, k >>= 1) if (k & 1) ans *= a;
	return ans;
}

const int maxn = 505;
int n;
Z P[505];
int Lspd[505], Rspd[505];
int id[505];
int getid(int u, int v) {
    if (u < 1 || u > n) return 0;
    if (v < Lspd[u] || v > Rspd[u]) return 0;
    return id[u] + v - Lspd[u];
}
int calc(int u, int v) {
    if (v >= Lspd[u] && v <= Rspd[u]) return -1;
    int cnt = 0;
    while (1) {
        if (v > 0) v--; else v++;
        u += v;
        if (u > n || u < 1) return cnt;
        cnt++;
    }
}

Z A[6005][6005];
Z ans[6005]; bool fucked[6005];

void printfrac(Z x) {
    for (int i = 1; i <= 1000000; i++)
        if ((x * i).x <= 1000000) { printf("%d : %d\n", (x * i).x, i); return; }
    for (int i = 1; i <= 1000000; i++)
        if ((-x * i).x <= 1000000) { printf("-%d : %d\n", (x * i).x, i); return; }
    printf("failed\n");
}

int main() {
    freopen("sail.in", "r", stdin);
    freopen("sail.out", "w", stdout);
    scanf("%d", &n);
    for (int i = 1; i <= n; i++) scanf("%d", &P[i].x), P[i] *= qpow(100, p - 2), P[i] = 1 - P[i];
    int idx = 0;
    for (int i = 1; i <= n; i++) {
        id[i] = idx + 1;
        for (int j = 0; ; j++)
            if (1LL * j * (j - 1) / 2 >= i) { Lspd[i] = 1 - j; break; }
        for (int j = 0; ; j++)
            if (1LL * j * (j - 1) / 2 >= n - i + 1) { Rspd[i] = j - 1; break; }
        idx += Rspd[i] - Lspd[i] + 1;
        // printf("check %d %d\n", Lspd[i], Rspd[i]);
    }
    // printf("%d\n", idx);

    for (int i = 1; i <= n; i++)
    for (int j = Lspd[i]; j <= Rspd[i]; j++) {
        int u = getid(i, j);
        A[u][u] = 1; A[u][idx + 1] = 1;
        if (i + j + 1 <= n && i + j + 1 >= 1) {
            int X = calc(i + j + 1, j + 1);
            if (X == -1) A[u][getid(i + j + 1, j + 1)] = -P[i];
            else A[u][idx + 1] += P[i] * X;
        }
        else A[u][idx + 1] -= P[i];
        if (i + j - 1 <= n && i + j - 1 >= 1) {
            int X = calc(i + j - 1, j - 1);
            if (X == -1) A[u][getid(i + j - 1, j - 1)] = P[i] - 1;
            else A[u][idx + 1] += (1 - P[i]) * X;
        }
        else A[u][idx + 1] -= 1 - P[i];
        // if (i == 1 && j == 0) {
        //     printf("test\n");
        //     for (int k = 1; k <= idx + 1; k++) if (A[u][k].x) printf("%d ", k), printfrac(A[u][k]);
        // }
    }

    for (int i = 1; i <= idx; i++) {
        if(!A[i][i].x)
        for (int j = i + 1; j <= idx; j++)
            if (A[j][i].x) {
                swap(A[i], A[j]);
                break;
            }
        if (!A[i][i].x) continue;
        Z X = qpow(A[i][i], p - 2);
        for (int j = i; j <= idx + 1; j++)
            A[i][j] *= X;
        for (int j = i + 1; j <= idx; j++) if (A[j][i].x) {
            Z tmp = A[j][i];
            for (int k = i; k <= idx + 1; k++) if (A[i][k].x)
                A[j][k] -= A[i][k] * tmp;
        }
    }

    for (int i = idx; i; i--) {
        if (!A[i][i].x) { fucked[i] = 1; continue; }
        ans[i] = A[i][idx + 1];
        for (int j = i + 1; j <= idx; j++) if (A[i][j].x)
            if (fucked[j]) {fucked[i] = 1; continue; }
            else ans[i] -= A[i][j] * ans[j];
        ans[i] *= qpow(A[i][i], p - 2);
    }

    // for (int i = 1; i <= n; i++)
    // for (int j = Lspd[i]; j <= Rspd[i]; j++) {
    //     printf("%d %d : ", i, j);
    //     if (!fucked[getid(i, j)]) printfrac(ans[getid(i, j)] + 1);
    //     else printf("-1\n");
    // }

    for (int i = 1; i <= n; i++)
        if (!fucked[getid(i, 0)]) printf("%d ", ans[getid(i, 0)] + 1);
        else printf("-1 ");
    // printfrac(296949559);
    // printfrac(121519793);
    // printfrac(954841266);
    // printfrac(180307337);
    // printfrac(650192900);
    // printfrac(662567916);
    // printfrac(277711980);
    // printfrac(549498100);
    // printfrac(761267253);
    // printfrac(495749568);
    // printfrac(95732595);
    // printfrac(469237483);
    // printfrac(906335585);
    // printfrac(438391734);
    // printfrac(151238224);


    // memset(A, 0, sizeof(A));
    // for (int i = 1; i <= n; i++)
    // for (int j = Lspd[i]; j <= Rspd[i]; j++) {
    //     int u = getid(i, j);
    //     A[u][u] = 1; A[u][idx + 1] = 1;
    //     if (i + j + 1 <= n && i + j + 1 >= 1) {
    //         int X = calc(i + j + 1, j + 1);
    //         if (X == -1) A[u][getid(i + j + 1, j + 1)] = -P[i];
    //         else A[u][idx + 1] += P[i] * X;
    //     }
    //     else A[u][idx + 1] -= P[i];
    //     if (i + j - 1 <= n && i + j - 1 >= 1) {
    //         int X = calc(i + j - 1, j - 1);
    //         if (X == -1) A[u][getid(i + j - 1, j - 1)] = P[i] - 1;
    //         else A[u][idx + 1] += (1 - P[i]) * X;
    //     }
    //     else A[u][idx + 1] -= 1 - P[i];
    // }

    // for (int i = 1; i <= idx; i++) {
    //     Z qaq = 0;
    //     for (int j = 1; j <= idx; j++)
    //         qaq += A[i][j] * ans[j];
    //     assert(qaq.x == A[i][idx + 1].x);
    // }
}

/*
15
41 52 56 69 14 70 9 21 96 98 53 22 51 88 33 

*/