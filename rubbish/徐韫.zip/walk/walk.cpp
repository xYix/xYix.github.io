#include<bits/stdc++.h>
using namespace std;

const int maxn = 300005;
int n;
vector<int> G[maxn];

int fa[maxn], dL[maxn], dR[maxn], idx;
int dep[maxn];
int a[maxn];
void init(int x, int f) {
    fa[x] = f; dL[x] = ++idx;
    dep[x] = dep[f] + 1;
    for (int y : G[x]) if (y != f)
        init(y, x);
    dR[x] = idx;
}

bool isvalid(int u, int v, int x, int y) {
    if (fa[u] != v && fa[v] != u) return 0;
    if (fa[u] != v) swap(u, v);
    int qaq = (dL[u] <= dL[x] && dL[x] <= dR[u]) + (dL[u] <= dL[y] && dL[y] <= dR[u]);
    return qaq == 1;
}

int main() {
    freopen("walk.in", "r", stdin);
    freopen("walk.out", "w", stdout);
    
    scanf("%d", &n);
    for (int i = 1; i <= n; i++) scanf("%d", &a[i]);
    for (int i = 1; i < n; i++) {
        int u, v; scanf("%d%d", &u, &v);
        G[u].push_back(v); G[v].push_back(u);
    }
    init(1, 0);
}