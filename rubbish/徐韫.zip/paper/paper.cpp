#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

const int maxn = 100005;
int n, B;
int inb[maxn], beg[400];
struct node {
	int x, y;
	int insT, delT;
	bool operator < (const node b) const { return x < b.x || (x == b.x && y < b.y); }
} A[maxn], A1[maxn];

vector<int> lis[400];
node HULL[maxn]; int len = 0;

int main() {
	freopen("paper.in", "r", stdin);
	freopen("paper.out", "w", stdout);
	
	scanf("%d", &n);
    // n = 100000;
    B = sqrt(n);
	for (int i = 1; i <= n; i++) {
		inb[i] = (i - 1) / B + 1;
		if (inb[i] != inb[i - 1])
			beg[inb[i]] = i;
	}
	beg[inb[n] + 1] = n + 1;
	for (int i = 1; i <= n; i++) {
		int opt/* = rand() % 3 + 1*/; scanf("%d", &opt);
		if (opt == 1) {
            // A[i].x = rand(); A[i].y = rand();
			scanf("%d%d", &A[i].x, &A[i].y);
			A[i].insT = i;
			A[i].delT = n + 1;
			lis[inb[i]].push_back(i);
		}
		else if (opt == 2) {
			int x/* = rand() % i*/; scanf("%d", &x);
            // while (A[x].insT < 0) x = rand() % i;
			A[i].insT = A[i].delT = -1;
			A[x].delT = i;
			if (x) lis[inb[i]].push_back(x);
		}
		else {
            // A[i].x = rand(); A[i].y = rand();
			scanf("%d%d", &A[i].x, &A[i].y);
			A[i].insT = A[i].delT = -2;
		}
	}

	for (int i = 1; i <= n; i++) A1[i] = A[i];
	sort(A1 + 1, A1 + n + 1);
	for (int nB = 1; nB <= inb[n]; nB++) {
		len = 0;
		for (int i = 1; i <= n; i++)
			if (A1[i].insT < beg[nB] && A1[i].delT >= beg[nB + 1]) {
				while (len >= 2 && 1LL * (HULL[len].x - HULL[len - 1].x) * (A1[i].y - HULL[len].y) >= 1LL * (A1[i].x - HULL[len].x) * (HULL[len].y - HULL[len - 1].y))
					len--;
				HULL[++len] = A1[i];
			}
		for (int i = beg[nB]; i < beg[nB + 1]; i++) if (A[i].insT == -2) {
			ll ans = 0;
			// on Convex Hull
			if (len) {
				int L = 1, R = len;
				while (L != R) {
					int mid = (L + R) >> 1;
					assert(mid != R);
					if (1LL * (HULL[mid + 1].x - HULL[mid].x) * A[i].y + 1LL * A[i].x * (HULL[mid + 1].y - HULL[mid].y) <= 0) R = mid;
					else L = mid + 1;
				}
				ans = max(ans, 1LL * A[i].x * HULL[L].x + 1LL * A[i].y * HULL[L].y);
			}
			// bruteforce
			for (int u : lis[nB]) if (A[u].insT < i && i < A[u].delT)
				ans = max(ans, 1LL * A[i].x * A[u].x + 1LL * A[i].y * A[u].y);
			printf("%lld\n", ans);
		}
	}
}