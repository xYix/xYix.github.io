#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef unsigned long long ull;

const int p = 998244353, g = 3, maxn = 1 << 18;
int qpow(int a, int k) {
	int ans = 1;
	for (; k; k >>= 1, a = (ull)a * a % p)
		if (k & 1) ans = (ull)ans * a % p;
	return ans;
}
int norm(int x) { return x >= p ? x - p : x; }
int mron(int x) { return x < 0 ? x + p : x; }
void add(int &x, int y) { if((x += y) >= p) x -= p; }
void sub(int &x, int y) { if((x -= y) < 0) x += p; }

vector<int> W[22];
int fac[maxn], ifac[maxn], inv[maxn];
void init(int n) {
	n++;
	for (int i = 0; i <= n; i++) {
		W[i].resize(1 << i);
		int w = qpow(g, (p - 1) >> i);
		W[i][0] = 1;
		for (int j = 1; j <= 1 << i; j++) W[i][j] = (ull)W[i][j - 1] * w % p;
	}
	inv[1] = fac[0] = fac[1] = ifac[0] = ifac[1] = 1;
	for (int i = 2; i < 1 << n; i++)
		fac[i] = (ull)fac[i - 1] * i % p,
		inv[i] = (ull)mron(-inv[p % i]) * (p / i) % p, assert((ull)inv[i] * i % p == 1),
		ifac[i] = (ull)ifac[i - 1] * inv[i] % p;
}

void DIF_(int d[], int n) {
	for (int L = n - 1, x = 1 << L; L >= 0; L--, x >>= 1)
	for (int *j = d; j < d + (1 << n); j += x << 1)
	for (int *k0 = j, *k1 = j + x, *w = W[L + 1].data(); k0 < j + x; k0++, k1++, w++) {
		int t = *k1;
		*k1 = (ull)mron(*k0 - t) * *w % p;
		add(*k0, t);
	}
}
void DIT_(int d[], int n) {
	for (int L = 0, x = 1; L < n; L++, x <<= 1)
	for (int *j = d; j < d + (1 << n); j += x << 1)
	for (int *k0 = j, *k1 = j + x, *w = W[L + 1].data() + (x << 1); k0 < j + x; k0++, k1++, w--) {
		int t = (ull)*k1 * *w % p;
		*k1 = mron(*k0 - t);
		add(*k0, t);
	}
	int invx = qpow(1 << n, p - 2);
	for (int i = 0; i < 1 << n; i++) d[i] = (ull)d[i] * invx % p;
}

struct Poly : vector<int> {
    using vector<int>::vector;
    void DFT(int n) {
        if (this->size() < 1 << n) resize(1 << n);
        DIF_(this->data(), n);
    }
    void iDFT(int n) {
        if (this->size() < 1 << n) resize(1 << n);
        DIT_(this->data(), n);
    }
};

Poly Conv(Poly d1, Poly d2, int n) {
	int x = 1 << n;
	d1.resize(x); d2.resize(x);
    if (n <= 3) {
    	Poly ans; ans.resize(x);
        for (int i = 0; i < x; i++)
        for (int j = 0; j < x; j++)
        	add(ans[(i + j) & (x - 1)], (ull)d1[i] * d2[j] % p);
        return ans;
    }
    d1.DFT(n); d2.DFT(n);
    for (int i = 0; i < x; i++) d1[i] = (ull)d1[i] * d2[i] % p;
    d1.iDFT(n);
    return d1;
}
Poly Add(Poly d1, Poly d2, int n) {
	int x = 1 << n;
    d1.resize(x); d2.resize(x);
    for (int i = 0; i < x; i++) add(d1[i], d2[i]);
    return d1;
}
Poly Inv(Poly d, int n) {
    Poly ans;
	if (n <= 3) {
    	ans.resize(1 << n);
		ans[0] = qpow(d[0], p - 2);
		for (int i = 1; i < 1 << n; i++) {
			int tmp = 0;
			for (int j = 0; j < i; j++) sub(tmp, (ull)ans[j] * d[i - j] % p);
			ans[i] = (ull)tmp * ans[0] % p;
		}
		return ans;
	}
    ans = Inv(d, n - 1); ans.resize(1 << n);
    int x = 1 << n;
    Poly P(ans.data(), ans.data() + x), Q(d.data(), d.data() + x);
	P.DFT(n), Q.DFT(n);
    for (int i = 0; i < x; i++) Q[i] = (ull)Q[i] * P[i] % p;
    Q.iDFT(n);
    for (int i = 0; i < x >> 1; i++) Q[i] = 0;
    Q.DFT(n);
    for (int i = 0; i < x; i++) Q[i] = (ull)Q[i] * P[i] % p;
    Q.iDFT(n);
    for (int i = x >> 1; i < x; i++) ans[i] = mron(-Q[i]);
    return ans;
}

Poly Ln(Poly d, int n) {
	Poly derd; derd.resize(1 << n);
	for (int i = 1; i < 1 << n; i++) derd[i - 1] = (ull)d[i] * i % p;
	derd = Conv(derd, Inv(d, n), n + 1);
	for (int i = 1 << n; i; i--) derd[i] = (ull)derd[i - 1] * inv[i] % p;
	derd[0] = 0;
	derd.resize(1 << n);
	return derd;
}
Poly Exp(Poly d, int n) {
    Poly ans;
    if (n == 0) { ans.push_back(1); return ans; }
    ans = Exp(d, n - 1);
    ans.resize(1 << n);
    Poly lnans = Ln(ans, n);
    for (int i = 0; i < 1 << n; i++) lnans[i] = mron(d[i] - lnans[i]);
    add(lnans[0], 1);
    ans = Conv(ans, lnans, n + 1);
    ans.resize(1 << n);
    return ans;
}

Poly f;

int main() {
	freopen("resent.in", "r", stdin);
	freopen("resent.out", "w", stdout);
	init(16);
	f.resize(1 << 16);
	int n, k; scanf("%d%d", &n, &k);
	// int n = 20, k = 4;
	int ki = k;
	for (int i = 1; i < 1 << 16; i++) {
		int tmp = 1LL * ki * qpow(1 - ki + p, p - 2) % p * (1 - qpow(ki, n) + p) % p * inv[i] % p;
		if (i & 1) f[i] = tmp;
		else f[i] = (p - tmp) % p;
		ki = 1LL * ki * k % p;
	}
	f = Exp(f, 16);
	for (int i = 1; i <= n; i++)
		printf("%d\n", 1LL * f[i] * fac[i] % p);
}