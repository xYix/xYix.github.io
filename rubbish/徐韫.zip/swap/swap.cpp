#include<bits/stdc++.h>
using namespace std;

const int maxn = 1000005;
struct node {
    int l, r;
    node *lc, *rc;
    int Lv, Rv;
    int minV, minpos;
    bool isans;
    void pushup() {
        Lv = lc -> Lv;
        Rv = rc -> Rv;
        isans = lc -> isans && rc -> isans && lc -> Rv < rc -> Lv;
        minV = lc -> minV, minpos = lc -> minpos;
        if (rc -> minV < minV) minV = rc -> minV, minpos = rc -> minpos;
    }
} T[maxn << 2], *rt; int idx;
int a[maxn];

node *Build(int l, int r) {
    node *x = T + idx++;
    x -> l = l, x -> r = r;
    if (l == r) {
        x -> Lv = x -> Rv = x -> minV = a[l];
        x -> minpos = l;
        x -> isans = 1;
    }
    else {
        int mid = (l + r) >> 1;
        x -> lc = Build(l, mid);
        x -> rc = Build(mid + 1, r);
        x -> pushup();
    }
    return x;
}
void Update(node *x, int pos) {
    if (x -> l == x -> r) {
        x -> Lv = x -> Rv = x -> minV = a[x -> l];
        x -> minpos = x -> l;
        x -> isans = 1;
        return;
    }
    if (pos <= x -> lc -> r) Update(x -> lc, pos);
    if (pos >= x -> rc -> l) Update(x -> rc, pos);
    x -> pushup();
}
void Query(node *x, int L, int R, node &ans) {
    if (L <= x -> l && x -> r <= R) {
        if (ans.minV == 0x3f3f3f3f) ans = *x;
        else {
            node tmp; tmp.lc = &ans, tmp.rc = x;
            tmp.pushup();
            ans = tmp;
        }
        return;
    }
    if (L <= x -> lc -> r) Query(x -> lc, L, R, ans);
    if (R >= x -> rc -> l) Query(x -> rc, L, R, ans);
}

int n, m;

int main() {
    freopen("swap.in", "r", stdin);
    freopen("swap.out", "w", stdout);
    
    scanf("%d%d", &n, &m);
    for (int i = 1; i <= n; i++) scanf("%d", &a[i]);
    rt = Build(1, n);
    while (m--) {
        int l, r; scanf("%d%d", &l, &r);
        node ans; ans.minV = 0x3f3f3f3f;
        Query(rt, l, r, ans);
        if (ans.isans) printf("-1\n");
        else {
            int u, v;
            if (a[l] != ans.minV)
                u = l, v = ans.minpos;
            else {
                int L = l, R = r - 1;
                node lans, rans;
                while (L != R) {
                    int mid = (L + R + 1) >> 1;
                    lans.minV = 0x3f3f3f3f;
                    Query(rt, l, mid, lans);
                    if (lans.isans) L = mid;
                    else R = mid - 1;
                }
                rans.minV = 0x3f3f3f3f;
                Query(rt, L + 1, r, rans);
                L = l;
                while (L != R) {
                    int mid = (L + R + 1) >> 1;
                    if (a[mid] > rans.minV) R = mid - 1;
                    else L = mid;
                }
                u = L + 1; v = rans.minpos;
            }
            swap(a[u], a[v]);
            Update(rt, u);
            Update(rt, v);
            printf("%d %d\n", u, v);
        }
    }
}