---
title: manufactoria 题解
---

曾经搞过这个隔膜，但是自从 flash 去世之后就再也没碰了。突然发现还有个 [js 版](https://www.xanthir.com/manufactoria/)，于是拿起来搓了一搓。可惜操作方式是真的反人类……

代码如下

**Level 1: Robotoast! ACCEPT: Move robots from the entrance (top) to the exit (bottom)!**

``lvl=1&code=c12:6f3;c12:7f3;c12:8f3;``

3 个元件，是最优解。

**Level 2: Robocoffee! If a robot's string starts with blue, accept. Otherwise, reject!**

``lvl=2&code=p12:6f2;c12:7f3;c12:8f3;``

3 个元件，是最优解。

**Level 3: Robolamp! ACCEPT: if there are three or more blues!**

``lvl=3&code=p12:5f3;c13:5f0;c11:5f3;p11:6f2;c11:7f3;p11:8f2;c11:9f3;c11:10f2;``

8 个元件，是最优解。

**Level 4: Robofish! ACCEPT: if a robot contains NO red!**

``lvl=4&code=p12:6f3;c11:6f2;c12:7f3;c12:8f3;``

4 个元件，是最优解。

**Level 5: Robobugs! ACCEPT: if the tape has only alternating colors!**

``lvl=5&code=p12:4f3;c12:6f3;c12:7f3;c12:8f3;c12:9f3;c12:10f3;p11:4f6;p13:4f4;p11:5f6;p13:5f4;c12:5f3;``

**Level 6: Robocats! ACCEPT: if the tape ends with two blues!**

``lvl=6&code=c12:4f3;p12:5f2;p12:6f2;p12:7f3;c11:7f2;c13:7f2;c14:7f1;c14:6f1;c14:5f1;c14:4f0;c13:4f0;c12:8f3;c12:9f3;c12:10f3;``

**Level 7: Robobears! ACCEPT: Strings that begin and end with the same color!**

