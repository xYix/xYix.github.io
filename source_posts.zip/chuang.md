---
title: 你要创作合集贴
---

## 第一届

[第一届中心页](https://www.luogu.com.cn/blog/zyxxs/post-ni-yao-chuang-zuo-bei-jie-long-tai-zhan-kai-mu)

[第一届宣传 PV](https://www.bilibili.com/video/BV1aW4y1V7vY)

[第一届](https://docs.qq.com/doc/DZHNCVUFETVl4VHRT?)

[第一届颁奖典礼 && 赛后总结](https://www.luogu.com.cn/blog/zyxxs/post-ni-yao-chuang-zuo-bei-yuan-man-bi-mu)

----

## 第二届

[第二届中心页](https://www.luogu.com.cn/blog/zyxxs/post-ni-yao-chuang-zuo-bei-di-er-jie-zhong-xin-ye)

[第二届宣传 PV](https://www.bilibili.com/video/BV1jV4y1m7vE)

[第二届（上）](https://docs.qq.com/doc/DZHdrb2pObG95VHFV)

[第二届（下）](https://docs.qq.com/doc/DZEVxZHZXUE5TTlB4)

[第二届颁奖典礼](https://docs.qq.com/doc/DZExDRkZlZndLZU9C)

[第二届赛后总结](https://www.luogu.com.cn/blog/zyxxs/ni-yao-chuang-zuo-bei-di-er-jie-sai-hou-zong-jie-tie)

----

## 第三届

[第三届](https://docs.qq.com/doc/DZGhlaExZbFVkSVZ0)

[第三届颁奖典礼](https://docs.qq.com/doc/DZFRwVHRLV09Ya3FW)