---
title: NayutanOI S 题解 - 彗星ハネムーン
---

虽然被 EI 爆标了但还是传一下吧

> **题目大意.**
>
> 给定 $n$ 和 $r$。问，有多少个不降非负整数序列的三元组：
>
> - $a_1\ge a_2\ge \ldots$（$a$ 长度无限）；
> - $b_1\ge b_2\ge \ldots$（$b$ 长度无限）；
> - $c_1\ge \ldots\ge c_{r}$。
>
> 满足：
>
> - $\sum a_i+\sum b_i+\sum c_i=n$；
> - $c_r\ge a_1,c_r\ge b_1$。
>
> 答案模 $998244353$。而且你要对 $0\le n<L$ 的所有 $n$ 求出答案。
>
> $L\le 5\times10^5,r\le 500$。

$r=0$ 应该是很简单的！大家应该都知道 **划分数**（把 $n$ 划分为任意长度的不升序列的方案数）的生成函数为
$$
\prod_{i=1}^{\infty}\dfrac{1}{1-x^i}
$$
其实就是枚举 $1\sim \infty$ 每个数用了几次。它有一个很简单的求法：根据 **五边形数定理**，它的逆元 $\prod_{i=1}^{\infty}(1-x^i)$ 非常好求，最后求个逆就好了。

而所问的就是 **"双划分"** 的个数，自然也就是
$$
\prod_{i=1}^{\infty}\dfrac{1}{(1-x^i)^2}
$$
也很简单。

下面我们称 $n$ 的双划分构成的集合为 $D_n$，并用 $\begin{bmatrix}a_1&a_2&\ldots\\b_1&b_2&\ldots\end{bmatrix}$  的形式表示一个双划分。

----

我们再来考虑 $r=1$ 的情况。~~我应该给这部分更多分的，但是很可惜它是 OEIS A001523。~~

不妨记所问的形如 $\left[c\quad\begin{matrix}a_1&a_2&\ldots\\b_1&b_2&\ldots\end{matrix}\right]$ 的东西构成的集合为 $V_{n}^{(1)}$ 或 $V_{n}^{(1,1)}$。

定义这样一个映射：
$$
V_{n}^{(1,1)}\rightarrow D_n=\left[c\quad\begin{matrix}a_1&a_2&\ldots\\b_1&b_2&\ldots\end{matrix}\right]\mapsto\begin{bmatrix}c&a_1&\ldots\\b_1&b_2&\ldots\end{bmatrix}
$$
这个映射并不是 **满** 的，形如
$$
\begin{bmatrix}a_1&a_2&\ldots\\b_1&b_2&\ldots\end{bmatrix},a_1<b_1
$$
的东西不会被映射到。出于某种原因，我们把 $b_1$ 提到前面作为 $c$，然后称这些元素为 $V_{n}^{(1,2)}$。现在的任务就是数出 $V_{n}^{(1,2)}$。

故技重施：
$$
V_{n}^{(1,2)}\rightarrow D_{n-1}=\left[c\quad\begin{matrix}a_1&a_2&\ldots\\b_1&b_2&\ldots\end{matrix}\right],c>a_1\mapsto\begin{bmatrix}c-1&a_1&\ldots\\b_1&b_2&\ldots\end{bmatrix}
$$
这次没有原像的元素形如
$$
\begin{bmatrix}a_1&a_2&\ldots\\b_1&b_2&\ldots\end{bmatrix},a_1+1<b_1\leftrightarrow\left[b_1\quad\begin{matrix}a_1+1&a_2&\ldots\\b_2&b_3&\ldots\end{matrix}\right],b_1>a_1+1>a_2
$$
再一次：
$$
V_n^{(1,3)}\rightarrow D_{n-3}=\left[c\quad\begin{matrix}a_1&a_2&\ldots\\b_1&b_2&\ldots\end{matrix}\right],c>a_1>a_2\mapsto\begin{bmatrix}c-2&a_1-1&\ldots\\b_1&b_2&\ldots\end{bmatrix}
$$
于是，
$$
\boxed{V_{n}^{(1)}=D_{n}-D_{n-1}+D_{n-3}-D_{n-6}+\ldots}
$$
生成函数形式也很容易写出。

---

接下来我们考虑 $r\ge2$ 的情形。不难发现，我们只需要数 $c$ 全相等的情况，最后乘上 $\dfrac{1}{\prod_{i=1}^{r-1}(1-x^i)}$ 就可以得到答案了。

我们先来考虑 $r=2$。定义一个新映射：
$$
V_{n}^{(2)}\rightarrow V_n^{(1,1)}=\left[c\ \ \ c\quad\begin{matrix}a_1&a_2&\ldots\\b_1&b_2&\ldots\end{matrix}\right]\mapsto\begin{bmatrix}c&a_1&\ldots\\c&b_1&\ldots\end{bmatrix}
$$
到达域中的无原像元素为：
$$
2\times \begin{bmatrix}a_1&a_2&\ldots\\b_1&b_2&\ldots\end{bmatrix},a_1<b_1\leftrightarrow2\times\left[c\quad\begin{matrix}a_1&a_2&\ldots\\b_1&b_2&\ldots\end{matrix}\right],c>a_1=V_{n}^{(1,2)}
$$

---

试试把这个扩展到 $r\ge 3$！
$$
V_{n}^{(r)}\rightarrow V_{n}^{(r-2)}=\left[...\ c\ \ \ c\ \ \ c\ \ \ c\quad\begin{matrix}a_1&a_2&\ldots\\b_1&b_2&\ldots\end{matrix}\right]\mapsto\left[...\ c\ \ \ c\quad\begin{matrix}c&a_1&\ldots\\c&b_1&\ldots\end{matrix}\right]
$$
无原像元素有两种情况。

- $c>a_1$ 且 $c>b_1$。对策：$c$ 集体减一后归为 $V_{n-r+2}^{(r-2)}$。
- $c=a_1>b_1$ 或 $a_1<b_1=c$。对策：把 $a_1,b_1$ 中的较大者拉入 $c$，归为（$2$ 倍数量的）$r-1$ 个 $c$，$c>a_1$，设该集合为 $U_{n}^{(r-1)}$。显然 $U_{n}^{(r-1)}$ 就是 $c\neq a_1$ 的 $V_n^{(r-1)}$，故 $U_{n}^{(r-1)}=V_{n}^{(r-1)}-V_{n}^{(r)}$。

即，
$$
2(V_{n}^{(r-1)}-V_{n}^{(r)})+V_{n}^{(r)}+V_{n-r+2}^{(r-2)}=V_{n}^{(r-2)}\\
\boxed{2V_{n}^{(r-1)}+V_{n-r+2}^{(r-2)}-V_{n}^{(r-2)}=V_{n}^{(r)}}
$$
即，设 $g_r=f_r\cdot\prod_{i=1}^{r-1}(1-x^i)$，则有
$$
\boxed{g_r=2g_{r-1}+(x^{r-2}-1)g_{r-2}}
$$

（其实 $r=2$ 不直接适用这个递推而是要修正一下，不过这应该是很容易的）

```cpp
#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef unsigned long long ull;

const int p = 998244353, g = 3, maxn = 1 << 21;
int qpow(int a, int k) {
	int ans = 1;
	for (; k; k >>= 1, a = (ull)a * a % p)
		if (k & 1) ans = (ull)ans * a % p;
	return ans;
}
int norm(int x) { return x >= p ? x - p : x; }
int mron(int x) { return x < 0 ? x + p : x; }
void add(int &x, int y) { if((x += y) >= p) x -= p; }
void sub(int &x, int y) { if((x -= y) < 0) x += p; }

vector<int> W[22];
int fac[maxn], ifac[maxn], inv[maxn];
void init(int n) {
	n++;
	for (int i = 0; i <= n; i++) {
		W[i].resize(1 << i);
		int w = qpow(g, (p - 1) >> i);
		W[i][0] = 1;
		for (int j = 1; j <= 1 << i; j++) W[i][j] = (ull)W[i][j - 1] * w % p;
	}
	inv[1] = fac[0] = fac[1] = ifac[0] = ifac[1] = 1;
	for (int i = 2; i < 1 << n; i++)
		fac[i] = (ull)fac[i - 1] * i % p,
		inv[i] = (ull)mron(-inv[p % i]) * (p / i) % p, assert((ull)inv[i] * i % p == 1),
		ifac[i] = (ull)ifac[i - 1] * inv[i] % p;
}

void DIF_(int d[], int n) {
	for (int L = n - 1, x = 1 << L; L >= 0; L--, x >>= 1)
	for (int *j = d; j < d + (1 << n); j += x << 1)
	for (int *k0 = j, *k1 = j + x, *w = W[L + 1].data(); k0 < j + x; k0++, k1++, w++) {
		int t = *k1;
		*k1 = (ull)mron(*k0 - t) * *w % p;
		add(*k0, t);
	}
}
void DIT_(int d[], int n) {
	for (int L = 0, x = 1; L < n; L++, x <<= 1)
	for (int *j = d; j < d + (1 << n); j += x << 1)
	for (int *k0 = j, *k1 = j + x, *w = W[L + 1].data() + (x << 1); k0 < j + x; k0++, k1++, w--) {
		int t = (ull)*k1 * *w % p;
		*k1 = mron(*k0 - t);
		add(*k0, t);
	}
	int invx = qpow(1 << n, p - 2);
	for (int i = 0; i < 1 << n; i++) d[i] = (ull)d[i] * invx % p;
}

struct Poly : vector<int> {
    using vector<int>::vector;
    void DFT(int n) {
        if (this->size() < 1 << n) resize(1 << n);
        DIF_(this->data(), n);
    }
    void iDFT(int n) {
        if (this->size() < 1 << n) resize(1 << n);
        DIT_(this->data(), n);
    }
};

Poly Conv(Poly d1, Poly d2, int n) {
	int x = 1 << n;
	d1.resize(x); d2.resize(x);
    if (n <= 3) {
    	Poly ans; ans.resize(x);
        for (int i = 0; i < x; i++)
        for (int j = 0; j < x; j++)
        	add(ans[(i + j) & (x - 1)], (ull)d1[i] * d2[j] % p);
        return ans;
    }
    d1.DFT(n); d2.DFT(n);
    for (int i = 0; i < x; i++) d1[i] = (ull)d1[i] * d2[i] % p;
    d1.iDFT(n);
    return d1;
}
Poly Add(Poly d1, Poly d2, int n) {
	int x = 1 << n;
    d1.resize(x); d2.resize(x);
    for (int i = 0; i < x; i++) add(d1[i], d2[i]);
    return d1;
}
Poly Inv(Poly d, int n) {
    Poly ans;
	if (n <= 3) {
    	ans.resize(1 << n);
		ans[0] = qpow(d[0], p - 2);
		for (int i = 1; i < 1 << n; i++) {
			int tmp = 0;
			for (int j = 0; j < i; j++) sub(tmp, (ull)ans[j] * d[i - j] % p);
			ans[i] = (ull)tmp * ans[0] % p;
		}
		return ans;
	}
    ans = Inv(d, n - 1); ans.resize(1 << n);
    int x = 1 << n;
    Poly P(ans.data(), ans.data() + x), Q(d.data(), d.data() + x);
	P.DFT(n), Q.DFT(n);
    for (int i = 0; i < x; i++) Q[i] = (ull)Q[i] * P[i] % p;
    Q.iDFT(n);
    for (int i = 0; i < x >> 1; i++) Q[i] = 0;
    Q.DFT(n);
    for (int i = 0; i < x; i++) Q[i] = (ull)Q[i] * P[i] % p;
    Q.iDFT(n);
    for (int i = x >> 1; i < x; i++) ans[i] = mron(-Q[i]);
    return ans;
}

int n, r;

int main() {
    int clk = clock();
	init(20);
    // scanf("%d%d", &n, &r);
    n = 1000000, r = 500;
    Poly Par(1 << 20), Par_R(1 << 20);
    Par[0] = 1;
    for (int i = 1; ; i++) {
        int x = i * (3 * i - 1) / 2;
        if (x >= 1 << 20) break;
        Par[x] = i & 1 ? p - 1 : 1;
        if ((x += i) < 1 << 20) Par[x] = i & 1 ? p - 1 : 1;
    }
    Par = Conv(Par, Par, 21); Par.resize(1 << 20);
    Par_R[0] = 1;
    int degPar = 0;
    for (int i = 1; i <= r - 1; i++) {
        for (int j = degPar; j >= 0; j--)
            sub(Par_R[j + i], Par_R[j]);
        degPar += i;
    }
    Par = Conv(Par, Par_R, 21); Par.resize(1 << 20);
    Par = Inv(Par, 20);

    Poly T(1 << 20);
    for (int i = 0; ; i++) {
        if (i * (i + 1) / 2 >= 1 << 20) break;
        T[i * (i + 1) / 2] = i & 1 ? p - 1 : 1;
    }
    
    Poly P[2] = {Poly(1 << 20), Poly(1 << 20)}, Q[2] = {Poly(1 << 20), Poly(1 << 20)};
    int degP[2] = {0, 0}, degQ[2] = {0, 0};
    P[1][0] = 1;
    P[0][0] = 2, Q[0][0] = p - 1;
    for (int i = 3; i <= r; i++) {
        int d = i & 1, rd = d ^ 1;
        for (int i = degP[d]; i >= 0; i--) sub(P[d][i + r - 2], P[d][i]);
        for (int i = degQ[d]; i >= 0; i--) sub(Q[d][i + r - 2], Q[d][i]);
        for (int i = 0; i <= degP[rd]; i++) add(P[d][i], P[rd][i]), add(P[d][i], P[rd][i]);
        for (int i = 0; i <= degQ[rd]; i++) add(Q[d][i], Q[rd][i]), add(Q[d][i], Q[rd][i]);
        degP[d] = max(degP[d] + r - 2, degP[rd]);
        degQ[d] = max(degQ[d] + r - 2, degQ[rd]);
    }
    T = Conv(T, P[r & 1], 21); T.resize(1 << 20);
    for (int i = 0; i < 1 << 20; i++) add(T[i], Q[r & 1][i]);

    Par = Conv(Par, T, 21);
    // for (int i = 0; i < n; i++) printf("%d ", Par[i]);
    printf("clock = %d\n", clock() - clk);
}
```

---

# 本题的理论速通方式

- 意识到可以推平 $c$，所以有 $1/(1-x)(1-x^2)\ldots(1-x^{r-1})$ 的结构；
- 在 OEIS 上搜索 $r=1$ 的数列，注意到 $\prod_{i=1}^{\infty}(1-x^i)^{-2}$ 和 $T=1-x+x^3-x^6+x^{10}-\ldots$ 的结构；
- 大胆猜想 $V_{n}^{(r)}=w_{n-i}D_i$，其中 $w_i$ 是与 $r,i$ 有关的容斥系数，即 $V_r=WD$；
- 高消打出 $W$ 的表，乘上 $(1-x)(1-x^2)...(1-x^{r-1})\prod_{i=1}^{\infty}(1-x^i)^2$，发现剩下的项极其稀疏，注意到 $p_rT-q_r$ 的结构；
- 试图求 $p_r,q_r$，搓出 $p_r,q_r$ 的递推。（或许你会对 $p$ 十分熟悉，事实上当 $x$ 为质数时 $p_r(x)$ 就是 $r-1$ 维向量空间的线性子空间个数，它有显然的递推）

~~这真的是人类能完成的吗~~

