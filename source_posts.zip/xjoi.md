---
title: 不能放到表世界的模拟赛记录
---

里世界变成垃圾场了属于是

但也发不出去啊，我也很绝望

构造！构造！构造！

### loj#3519 - 【CCO 2018 Day2】Flop Sorting

表世界有。

### 11/15 T3

**解法一**：（来自 Flying2018）

<div style="width:30%;margin:auto"><img src="https://xyix.github.io/images/xjoi-11-15.png" alt=""></div>

我们可以在常数步内同时交换 $(x,y)$ 和 $(u,v)$。因此，只要把叶子搞对（这是不难的），剩下的事情就显然了。

**解法二**：（来自 OIerwanhong）[here](https://www.luogu.com.cn/blog/c2522943959/xjoi-1115-post)

