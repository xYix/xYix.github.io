---
title: Restart
---

**Q :** 嗯……因为众所周知的原因去搞文化课了啊。

**A :** 确实。

**Q :** [Dr. Medako 的提案](https://xyix.github.io/posts/?postname=code-name-apotheosis) 会把剩下的内容续上吗？

**A :** 当时 NOIP2021 之后紧接文化课，每周都累成狗所以周末都在抓紧时间颓废（？），根本没时间静下心理清自己的思绪，回来继续写这篇文章。

后来？淡忘了？走出了？克服了？或许正如我在那篇文章末尾所说，"一股无法言说的感情涌上心头，不是悲痛，亦不是悔恨。"总之已经没有那种情感，没法再续上了。

其实还有一个原因是本来要写的东西被我改去越改越怪完全认不出来了（？）。（可以说，《干燥》《食盐》都是源自于《Dr.Medako 的提案》的将写未写的废稿的）

**Q :** 会觉得对不起 Dr.Medako 吗？

**A :** 对我而言她可能只是换了一种方式存在了？她是杀不死的。

<div style="width:40%;margin:auto"><img src="https://xyix.github.io/images/philo.png" alt=""></div>

**Q :** 为什么这么鸽？

**A :** 我写东西就是很慢，很多时候就是兴致到了就在草稿本上记一两句话，靠这种方式把文章写完。（这样生成的文章居然能够前后连贯简直是奇迹……）逼我写我一个字也憋不出来，所以别催辣别催辣

**Q :** 为什么不新开一个博客呢？

**A :** 很简单，我寻求理解。（但这很困难，我觉得用幻想和隐喻的方式已经是我能做到的最好了。）所以我自然必须把**前因**后果给展现出来。如果没有前 200 篇博文，读者就不可能真的领会《Dr.Medako 的提案》以及其他作品。

**Q :** 部分作品太晦涩难懂了，会有解析吗？

**A :** 不会。正如德国哲学家[普莱奥利](https://xyix.github.io/posts/?postname=proverb-of-medako)所言，“再多的言语也填不上人心中无思想的虚空”，给出答案除了损害读者的思维能力外一无用处。思考！如果你读不懂……总有一天你会读懂的。

如果说我一定要给一个提示的话，那就是下面这个：

“不要猜测作者的生平。要想想**你的**生平。”

我也很期待读者给出独具特色的解析。不要害怕让你的解析超过作者。

**Q :** 感谢您的回答。

这篇文章将长期作为 Q&A 板块，以回答作者觉得有必要回答的问题。至今所有的问题到此结束。谢谢您的观看。

（未完待续。）

## 值得一提的作品列表

### 杂

[SCP-XJ-404 - "禁止访问"](https://xyix.github.io/posts/?postname=xj-404) - "他们还在尖啸，但你永远也不会知道了。"

[伪装成人类的第 29 天](https://xyix.github.io/posts/?postname=dr-medako-origin) - "其上的皮肤缓缓绽开，露出了下面银白色的电机。"

[Dr.Medako 的提案](https://xyix.github.io/posts/?postname=code-name-apotheosis) - "不过，你真的很幸运，在这茫茫宇宙，这奇异的万古中，竟然有一个人与一颗星星心灵相通了。"

[望海潮](https://xyix.github.io/posts/?postname=the-shattering-of-delusion) - "而你现在又得捡起刚刚被你摔碎的妄想了。"

### 仙女座信号

[干燥](https://xyix.github.io/posts/?postname=drought) - "然后，我就什么都看不见了。"

[食盐](https://xyix.github.io/posts/?postname=salt) - "雨，那么你今天来是为了什么？"

[万花筒](https://xyix.github.io/posts/?postname=kaleidoscope) - "我带着无尽的悲哀与无尽的安慰发现，我的书桌上有两张一模一样的图案。"

[塔的寓言](https://xyix.github.io/posts/?postname=the-parable-of-the-tower) - "而我将在这散发着发酵腐烂的诱人甜香的城市中永远游荡，徒劳地寻找来时的入口。"

[工厂（和虚无主义）](https://xyix.github.io/posts/?postname=factory-nihilism) - "我现在确定，神明已经死了，这个世界已经死了，而我们不知道为什么还活着。"

[奔月](https://xyix.github.io/posts/?&postname=moon) - "眼中所见耳中所闻肌肤所感皆为虚假的现象，能称之为真实的唯有人心中激荡浮动的感情。"

[酒精](https://xyix.github.io/posts/?&postname=alcohol) - "他开始思考，那个迷宫会是什么样的。也许是如烟云，如雾气，可以被人吸进身体，可以在人血管中循环流动。他设想一座酒精的迷宫。"

[另一个塔的寓言](https://xyix.github.io/posts/?&postname=another-para-to) - "我敲敲箱子的玻璃盖，没有动静；我又改成轻拍，还是一样。最后我站在一旁，靠着柜子，手足无措。我想叫大人来，但夜太静了，我喉咙里发不出声音。"

### 晶体学、宇宙学、政治哲学

[飛行少女](https://xyix.github.io/posts/?&sortby=id&postname=hikou-shoujo) - "你相信吗？总有一天，像我们这样的人会占满这篇土地，整个世界都会是我们的族群？"

