---
title: AGC040F 题解 - Two Pieces
---

> **题目大意.**
>
> 你有两个无法区分的棋子，初始都在数轴的原点位置。
>
> 你有两种操作：
>
> - 把某个棋子移一步；
> - 把落后的棋子移到和另一枚棋子同一格。
>
> 问有多少种长度为 $n$ 的操作序列（**指每一步棋子占据的 pos 集合**）使得最终一枚棋子在 $A$，一枚棋子在 $B$。
>
> $n\le 10^7$。

- 不妨认为两枚棋子移到同一处总是二操作的结果。
- 不妨认为总是有一枚"左棋子"和"右棋子"，一操作也拆成"左移动"和"右移动"。

那么现在最本质的量是左棋子和右棋子的距离 $d$。而三个操作的效果分别为：

- $d\leftarrow d +1$，此操作必须恰好进行 $A$ 次；
- $d\leftarrow d-1$，此操作禁止使 $d$ 为 $0$；
- $d\leftarrow 0$。

枚举二、三操作的次数（加起来是 $n-A$）。

先忽视三操作，求出这时 $d$ 的变化情况，再考虑插入：我们来说明**这时插入的选择数与 $d$ 的具体细节无关。**

- 那么两个三操作之间不能存在 $d_i\ge d_j$；
- 且最后一次三操作插入的位置恰好是 $d_i+A-B=d_n$。

那么事实上最后一次三操作的位置已经确定了，即最后一次 $d_i+A-B=d_n$。

同理，倒数第二次三操作则是其之前的最后一次 $d_j-k=d_i,k\ge 0$……以此类推，是个组合数。

```cpp
#include<bits/stdc++.h>
using namespace std;

const int p = 998244353, maxn = 10000005;
struct Z {int x; Z(int x0 = 0) : x(x0) {}};
int inline check(int x) { return x >= p ? x - p : x; }
Z operator +(const Z a, const Z b) { return check(a.x + b.x); }
Z operator -(const Z a, const Z b) { return check(a.x - b.x + p); }
Z operator -(const Z a) {return check(p - a.x);}
Z operator *(const Z a, const Z b) { return 1LL * a.x * b.x % p; }
Z& operator +=(Z &a, const Z b) { return a = a + b; }
Z& operator -=(Z &a, const Z b) { return a = a - b; }
Z& operator *=(Z &a, const Z b) { return a = a * b; }
Z qpow(Z a, int k) {
	Z ans = 1;
	for (; k; a *= a, k >>= 1) if (k & 1) ans *= a;
	return ans;
}
Z fac[maxn], ifac[maxn], inv[maxn];
Z C(int n, int m) {
	if (n == m) return 1;
	if (n < 0 || m < 0 || n < m) return 0;
	return fac[n] * ifac[m] * ifac[n - m];
}
void init() {
	inv[1] = fac[0] = fac[1] = ifac[0] = ifac[1] = 1;
	for (int i = 2; i < maxn; i++)
		fac[i] = fac[i - 1] * i,
		inv[i] = -inv[p % i] * (p / i),
		ifac[i] = ifac[i - 1] * inv[i];
}

int main() {
	init();
	int n, A, B; scanf("%d%d%d", &n, &A, &B);

	Z ans = 0;
	for (int k = 0; k <= min(n - A, A) && k <= min(n - B, B); k++) {
		Z w = C(k + B - 1, B - 1) - C(k + B - 1, B);
		assert(k != 0 || w.x == 1);
		int x = n - B - k - 1,
			y = A - k + 1;
		ans += w * C(x + y - 1, x);
	}
	printf("%d\n", ans);
}
```



