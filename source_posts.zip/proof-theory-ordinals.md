---
title: 序数和证明论
---

还记得[上期](https://xyix.github.io/posts/?&sortby=id&postname=big-numbers)我们提到过“皮亚诺公理体系（Peano Arithmetic，PA）在 $\varepsilon_0$ 会崩坏”。当时我们是说函数 $f_{\varepsilon_0}$ 在 PA 下无法证明在每一个 $n$ 处都有定义。但事实上，在 PA 讨论 $\varepsilon_0$ 就已经很可疑了：事实上，PA **不能**证明 $\varepsilon_0$ 的存在。

哥德尔不完备定理告诉我们，那些我们所熟悉的那些含有初等算术（自然数）的证明论体系中，一定存在不能被证明也不能被证伪的命题。在上面的例子中，它就是 $\varepsilon_0$ 的存在性。

事实上，对于任何一个证明论体系，我们总是可以把所有它能证明存在的序数的集合看成一个序数，一个更大的，不能被该体系证明的序数。这个序数被称为该体系的**证明论序数（Proof-Theoretic Ordinal，PTO）**，有关证明论序数的研究则被称为**序数分析（Ordinal Analysis）**。

## 1.

所以为什么说 $f_{\varepsilon_0}$ 无法在 PA 里被证明处处有定义？现在仍无法解释，但我可以给你举另外一个相似的例子。

如果把 PA 去掉归纳法就是 Robinson Arithmetic，证明论上记作 $\text{Q}$。在 Robinson Arithmetic 中，所有具体的算术命题，如 $2+3=3+2$，都可以被证明或证伪；但由于没有归纳法，所有形如"$\forall x,y\in \mathbb{N},x+y=y+x$"的命题都无法被证明或证伪。

在 $\text{Q}$ 中，由于后继的存在，我们可以简单地定义加法：

- $x+0=x$
- $x+S(y)=S(x+y)$

看着和 PA 很像，但是请注意我们没有承认所有自然数总可以被分为“$0$”和“某个数的后继”两类。

由此，加法可以被*定义*，但我们不能证明加法在所有 $x+y$ 上都能正常运作，也就是说，$\text{Q}$ 是如此之弱以至于任意 $f_{n}$（虽然可以被定义，但）都无法被证明处处有定义。

----

再看一个例子，皮亚诺算术的一阶逻辑版本 PA-。一阶逻辑就是所谓谓词逻辑，允许在非逻辑对象上使用量词；而皮亚诺算术本身是二阶逻辑，允许在谓词变元上用量词。比如：

- 在一阶逻辑中，我们可以说 $\exists x,\text{succ}(x)=y$。
- 而只有在二阶逻辑中，我们才能说 $\exists\text{P},\text{P}(n)$。

这有一个重要的推论，那就是在二阶逻辑中我们可以在非逻辑对象的集合上使用量词（我们没必要知道“非逻辑对象”到底是什么。对象是可以随意选择的，即使它们本身是集合也不影响***公式本身***的阶。），因为对象上的单参数谓词本身显然唯一对应一个集合。

在弱化的皮亚诺算术中，每个一阶谓词 $\varphi$ 都有一个对应的归纳法公理：
$$
\forall\overline y,(\varphi(0,\overline y)\land(\forall n,\varphi(n,\overline y)\rightarrow\varphi(\text{succ}(n),\overline y)))\rightarrow\forall n,\varphi(n,\overline y)
$$
其中 $\overline y$ 是谓词 $\varphi$ 的其他可能的参数 $y_1,y_2,\ldots,y_k$ 的缩写。

而在二阶的皮亚诺算术中，任意谓词 $\varphi$ 都可以进行归纳。

----

那么 PA- 比 PA 弱在了哪里？

事实上，PA- 根本不能*确定*（精确到同构）自然数的结构。事实上有很多鬼畜的**模型**也符合 PA-，这些模型被称为**非标准模型**。

其中一个非标准模型的序型是 $\omega+(\omega^*+\omega)\cdot\eta$。其中 $\omega^*$ 是反向的 $\omega$，即一条无穷下降的链条，和 $\omega$ 相加相当于 $\mathbb Z$ 的序型；而 $\eta$ 则是 $\mathbb Q$ 的序型。把它们相乘意味着有有理数多个像 $\mathbb Z$ 一样的链条。

这……是啥？？？

### 参考资料

[1] [Ordinal Analysis](https://en.wikipedia.org/wiki/Ordinal_analysis) 及关联页面, Wikipedia。

[2] [Contents of Gentzen's consistency proof of PA](https://math.stackexchange.com/questions/2856263/contents-of-gentzens-consistency-proof-of-pa), Stackexchage。

[3] [Gentzen’s Consistency Proof](https://logic.pku.edu.cn/docs/20230508221236673395.pdf), 刘力恺。
