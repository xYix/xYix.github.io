---
title: luoguP7124 题解 - 【Ynoi2008】stcm
---

> **题目大意.**
>
> 给出一棵树。有一个初始为空的点集 $S$，你可以进行两种操作共 $4.5\times10^6$ 次：
>
> - 插入一个点；
> - 撤销上一次操作。
>
> 请构造出所有 $n$ 个子树的补。
>
> $n\le 10^5$​。

自然考虑树分治，先来个重剖。目前流程为：

```
solve(x) :
	暴力加入整个子树，报告 x 所在重链构造成功
	solve_light([轻儿子们]) // 用神秘的方法处理轻子树，其中轻子树指的是与该重链所连的所有子树
```

我们当然可以爆枚所有重链上的节点然后对其所有轻子树分治，但是这样复杂度是两只 log（轻边数 $\times$ 分治的复杂度）的，过不去。

考虑把整条重链上的所有轻儿子放在一起分治：

<center><img src="https://xyix.github.io/images/luogu-7124.png" style="width: 80%" alt=""></center>

兄啊，你这树高不还是 $\log n$ 的吗（疑惑）

但这时我们可以这样想象：把所有重链的分治树接起来，我们所要追求的就是整棵分治树的树高为 log。（听起来很像全局平衡二叉树啊）那我们只需要按子树大小带权分治就可以了。复杂度理论上是 $n\log_{1.5}n$，实际上大概跑不满。

话说哈夫曼树是啥？似乎和带权分治等价的吧？

为什么你们常数这么小？

```cpp
#include<bits/stdc++.h>
using namespace std;
 
const int maxn = 100005;
int n;

vector<int> G[maxn];
int fa[maxn], siz[maxn], son[maxn];
void dfs(int x, int f) {
	fa[x] = f; siz[x] = 1; son[x] = 0;
	for (int y : G[x]) {
		dfs(y, x);
		if (siz[y] > siz[son[x]]) son[x] = y;
		siz[x] += siz[y];
	}
}

void solve(int x, int dep);
void solve_heavy(int x);
void solve_light(int l, int r, int sum, int dep);
void cover(int x, bool flg, bool typ);

void cover(int x, bool flg, bool typ) {
	if (!flg) {
		int cnt = typ ? 1 : siz[x];
		while (cnt--) printf("-");
		return;
	}
	printf("+%d", x);
	if (typ) return;
	for (int y : G[x]) cover(y, 1, 0);
}
int lis_[40][maxn], typ_[40][maxn], len_[40];
int *lis, *typ, *len;
void solve(int x, int dep) {
	lis = lis_[dep], typ = typ_[dep]; len = &len_[dep];
	*len = 0;
	solve_heavy(x);
	int sum = 0;
	for (int i = 1; i <= *len; i++) sum += (typ[i] ? 1 : siz[lis[i]]);
	if (len) solve_light(1, *len, sum, dep);
}
void solve_heavy(int x) {
	printf("=%d", x);
	(*len)++; lis[*len] = x; typ[*len] = 1;

	if (!son[x]) return;

	printf("+%d", x);

	for (int y : G[x]) if (y != son[x])
		cover(y, 1, 0), 
		(*len)++, lis[*len] = y, typ[*len] = 0;
	solve_heavy(son[x]);
	for (int y : G[x]) if (y != son[x]) cover(y, 0, 0);

	printf("-");
}
void solve_light(int l, int r, int sum, int dep) {
	if (l == r) {
		if (!typ[l]) {
			solve(lis[l], dep + 1);
			lis = lis_[dep], typ = typ_[dep], len = &len_[dep];
		}
		return;
	}
	int mid = l, lsum = 0;
	for (; ; mid++) {
		lsum += (typ[mid] ? 1 : siz[lis[mid]]);
		if (lsum >= sum / 2) break;
		if (mid == r - 1) break;
	}

	for (int i = mid + 1; i <= r; i++) cover(lis[i], 1, typ[i]);
	solve_light(l, mid, lsum, dep);
	for (int i = mid + 1; i <= r; i++) cover(lis[i], 0, typ[i]);
	
	for (int i = l; i <= mid; i++) cover(lis[i], 1, typ[i]);
	solve_light(mid + 1, r, sum - lsum, dep);
	for (int i = l; i <= mid; i++) cover(lis[i], 0, typ[i]);
}
 
int main() {
	while (scanf("%d", &n) != EOF) {
		for (int i = 2; i <= n; i++) {
			int u; scanf("%d", &u);
			G[u].push_back(i);
		}
		dfs(1, 0);
		solve(1, 0);
		printf("!\n");
		for (int i = 1; i <= n; i++) G[i].clear();
	}
}
```



