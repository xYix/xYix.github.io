---
title: 庆祝叉义叉在基金会中分的作者页上线
---

[在这里！](http://scp-wiki-cn.wikidot.com/x-yi-x-author-page)

因为放假这两天 Stellaris 时长太长了，所以已经失去了思考能力，作者页只好把之前写的一些怪东西一锅乱炖。

又小又破就又小又破吧，总算有了自己的作者页还是真的令人很开心的。

不管怎么样我先放个 medako 在这里。

![](/images/author-page-cele.png)