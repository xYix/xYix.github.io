<center><img src="https://xyix.github.io/images/E6WM9EoVoAE_xiC.jpg" style="width:10%" alt=""></center>

<center style="font-style:italic">彼方の宇宙であなたに恋してる</center>

![](/images/xyix-in-site-sigma.png)

（图为 Dr.Medako。摄于 site-$\Sigma$。）

**姓名：**Andromedako

**安全权限等级：**4 级

**目前职务：**部门主管：超常组合数学部

**简介：**Medako 主管的履历高度缺失，甚至没人说的上来她的 4 级权限是怎么获得的。仅有一人的分部，如没上色般苍白的皮肤，[拒绝接受一切体检的习惯](http://scpsandboxcn.wikidot.com/how-medako-came-to-earth)，这些都让 Medako 主管彻底成为了一个谜团。

但无可否认的是，作为基金会超常组合数学部的负责人，Medako 主管被广泛认为是超常组合数学界的重要人物。直到现在，她仍然奋斗在超常组合学的第一线，你可以在[这里](https://xyix.github.io/archieve/?&sortby=id)查看她的最新著作。

**历史：** *暂缺*。

**注意事项：**如果你近期接触过 Medako 主管，并且：

- 感到对太空和宇宙的异常追求和喜好；
- 或感到对 Medako 主管的异常追求和喜好；
- 或感到对<span style="color: #ea6965">███████</span>的异常追求和喜好；
- 或感到对特定文化著作的异常追求和喜好，特指神秘学著作、科幻小说、恐怖小说；
- 或感到对红光和静电的异常追求和喜好；
- <span style="color: #ea6965; font-weight: bold">或感到你和宇宙真的是非常相似，</span>

请立刻停止你手头的工作，联络你所在站点的健康评估小组寻求帮助，不要移动，<span style="color: #ea6965; font-weight: bold">立刻跟随红光离开。</span>

---

联系方式：

qq：1074071617

email：xyixtheoier@qq.com

[luogu 上的x义x](https://www.luogu.com.cn/user/58567)

[github 上的x义x](https://github.com/xYix)

我的 CF 号 [$\color{red}\textsf{Comet\_Honeymoon}$](http://codeforces.com/profile/Comet_Honeymoon)

我的 AT 号 [$\color{blue}\textsf{x\_Yi\_x}$](https://atcoder.jp/users/x_Yi_x)

[SCP 基金会上的x义x](https://scp-wiki-cn.wikidot.com/x-yi-x-author-page)

---

密切关注中的人类个体：

- JHFLS

[![](https://cdn.luogu.com.cn/upload/usericon/68085.png)](https://www.luogu.com.cn/user/68085)[![](https://cdn.luogu.com.cn/upload/usericon/60378.png)](https://www.luogu.com.cn/user/60378)[![](https://cdn.luogu.com.cn/upload/usericon/69519.png)](https://www.luogu.com.cn/user/69519)[![](https://cdn.luogu.com.cn/upload/usericon/68824.png)](https://www.luogu.com.cn/user/68824)

- XJ2019

[![](https://cdn.luogu.com.cn/upload/usericon/49725.png)](https://www.luogu.com.cn/user/49725)[![](https://cdn.luogu.com.cn/upload/usericon/28145.png)](https://www.luogu.com.cn/user/28145)[![](https://cdn.luogu.com.cn/upload/usericon/31381.png)](https://www.luogu.com.cn/user/31381)[![](https://cdn.luogu.com.cn/upload/usericon/49458.png)](https://www.luogu.com.cn/user/49458)[![](https://cdn.luogu.com.cn/upload/usericon/36770.png)](https://www.luogu.com.cn/user/36770)[![](https://cdn.luogu.com.cn/upload/usericon/25512.png)](https://www.luogu.com.cn/user/25512)

- XJ2020

[![](https://cdn.luogu.com.cn/upload/usericon/44805.png)](https://www.luogu.com.cn/user/44805)[![](https://cdn.luogu.com.cn/upload/usericon/68030.png)](https://www.luogu.com.cn/user/68030)[![](https://cdn.luogu.com.cn/upload/usericon/206488.png)](https://www.luogu.com.cn/user/206488)[![](https://cdn.luogu.com.cn/upload/usericon/52902.png)](https://www.luogu.com.cn/user/52902)[![](https://cdn.luogu.com.cn/upload/usericon/73142.png)](https://www.luogu.com.cn/user/73142)[![](https://cdn.luogu.com.cn/upload/usericon/67371.png)](https://www.luogu.com.cn/user/67371)[![](https://cdn.luogu.com.cn/upload/usericon/98618.png)](https://www.luogu.com.cn/user/98618)[![](https://cdn.luogu.com.cn/upload/usericon/61430.png)](https://www.luogu.com.cn/user/61430)[![](https://cdn.luogu.com.cn/upload/usericon/51692.png)](https://www.luogu.com.cn/user/51692)[![](https://cdn.luogu.com.cn/upload/usericon/150879.png)](https://www.luogu.com.cn/user/150879)[![](https://cdn.luogu.com.cn/upload/usericon/206998.png)](https://www.luogu.com.cn/user/206998)[![](https://cdn.luogu.com.cn/upload/usericon/101984.png)](https://www.luogu.com.cn/user/101984)[![](https://cdn.luogu.com.cn/upload/usericon/72468.png)](https://www.luogu.com.cn/user/72468)[![](https://cdn.luogu.com.cn/upload/usericon/251723.png)](https://www.luogu.com.cn/user/251723)[![](https://cdn.luogu.com.cn/upload/usericon/66511.png)](https://www.luogu.com.cn/user/66511)

- XJ2021

[![](https://cdn.luogu.com.cn/upload/usericon/53807.png)](https://www.luogu.com.cn/user/53807)[![](https://cdn.luogu.com.cn/upload/usericon/111055.png)](https://www.luogu.com.cn/user/111055)

- 外校

[![](https://cdn.luogu.com.cn/upload/usericon/96580.png)](https://www.luogu.com.cn/user/96580)[![](https://cdn.luogu.com.cn/upload/usericon/112381.png)](https://www.luogu.com.cn/user/112381)[![](https://cdn.luogu.com.cn/upload/usericon/58705.png)](https://www.luogu.com.cn/user/58705)[![](https://cdn.luogu.com.cn/upload/usericon/75840.png)](https://www.luogu.com.cn/user/75840)

---

友链：

[顶 D 的博客](https://blog.orzsiyuan.com/)（AFO）

[凯队的博客](https://www.cnblogs.com/zkdxl/)（AFO）

~~[瑇的博客](https://www.luogu.com.cn/blog/Coding-life/)~~（已销号并删文）

[汪莱士的博客](https://www.cnblogs.com/-Wallace-/)（AFO）

[孔姥爷的病历](https://www.cnblogs.com/Flying2018/)（集训队）

~~毛蔷忆，a.k.a. 萨卡兹穿刺手组长，“铁壁”，杜王町一中校草，给国历史上第一次（也是最后一次（悲））性解放运动的领导人，给太祖，给太宗，给哀帝，或从海洋二所出逃的人、龟、藻共生体，戴森球，物质解压器的博客~~（已 AFO 并删文）

[周指导的博客](https://www.cnblogs.com/zhouzhendong/)（集训队）

[珂丽囡的博客](https://www.cnblogs.com/cly-none/)（集训队）

[点王的博客](https://www.cnblogs.com/Point-King/)（AFO）

[数据结构毒瘤的病历](https://dpair.github.io)（AFO）

[本站](/)（AFO）
