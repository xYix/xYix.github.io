---
title: x义x 的糖学研究
---

糖学，顾名思义，就是研究 vocaloid P 主 [Nayutalien](https://twitter.com/Nayutalien) 所作的曲子的学问。（萌娘百科上的[词条](https://zh.moegirl.org.cn/Nayutan%E6%98%9F%E4%BA%BA)附）

此处无需交代该 P 主对 x义x 有多大的影响，由 x义x 的头像立即可见。

## Q1 : 为什么会存在糖学？

Nayutalien（下称奶油糖）所作的曲目大多讲述了一个独特的小故事，而歌词所直接表达的却往往零零散散甚至没啥逻辑，同时又保持了足够的神秘感和许多重要信息，让人很难不探究这背后的真相。

类比一下土（MARETU）学就很好理解了（？）

## Q2 : 奶油糖的曲目构成？

上文我们已经说过，奶油糖的曲目大多是一个个独特的小故事，这些小故事有许多有类似的主题，可以大致分为两类：（曲目用颜色指示专辑，方便读者查阅）

- 童话故事类（例：<span style="color: #3dbeee; font-weight: bold">Rocket Cider</span>，<span style="color: #3dbeee; font-weight: bold">Strato Stella</span>，<span style="color: #ea6965; font-weight: bold">行星环</span>，<span style="color: #36c48e; font-weight: bold">星之王子</span>，<span style="color: #36c48e; font-weight: bold">明星银河号</span>，<span style="color: #36c48e; font-weight: bold">彗星蜜月</span>，<span style="color: #ff83b7; font-weight: bold">木星节拍</span>，空中战系列）
- 校园/青春类（例：<span style="color: #3dbeee; font-weight: bold">Andromeda Andromeda</span>，<span style="color: #3dbeee; font-weight: bold">How to Warp</span>，<span style="color: #3dbeee; font-weight: bold">飞行少女</span>，<span style="color: #ea6965; font-weight: bold">Alien Alien</span>，<span style="color: #ea6965; font-weight: bold">太阳系 disco</span>，<span style="color: #ea6965; font-weight: bold">Mystery Cycle</span>，<span style="color: #ea6965; font-weight: bold">Airy Fall</span>，<span style="color: #ff83b7; font-weight: bold">Meteor</span>）

可以看出，以上的分类其实不是很严谨，各类之间并非界限分明，仅仅是大致归类而已。

事实上，童话故事类也是在隐喻少年少女的精神状态，而校园/青春类也只是背景故事不那么惹眼而已。

总之，我们可以看出：

- 奶油糖善于用童话故事作隐喻；
- 故事的真相应当是指向少年少女们的所思所想。

## Q3 : 这些故事之间有什么呼应吗？

这就来到了糖学最开始引起人们注意的特征了：奶油糖会用多首歌、两个视角（男主/女主）讲同一个故事。

- 最经典的例子非 <span style="color: #3dbeee; font-weight: bold">Rocket Cider</span> 与 <span style="color: #36c48e; font-weight: bold">彗星蜜月</span> 莫属，
- <span style="color: #3dbeee; font-weight: bold">水星华尔兹</span>，<span style="color: #ea6965; font-weight: bold">Regulus</span>，<span style="color: #ff83b7; font-weight: bold">银河电灯</span>：这一系列的后两首歌提及了铁路/车站，前两首歌则是送别之曲。而<span style="color: #ff83b7; font-weight: bold">银河电灯</span>直接不演了，明示了这是源自《银河铁道之夜》，更加印证了前两首在 <span style="color: #ff83b7; font-weight: bold">N</span> 专发售前就被认为是隐喻生死的看法。