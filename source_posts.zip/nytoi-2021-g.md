---
title: NayutanOI G 题解 - 月光ミュージック
---

> **题目大意.**
>
> 现有 $m$ 种颜色的边，第 $i$ 种颜色的边有 $n_i$ 条，同色边互相之间无法区分。
>
> 现在要把这些边首尾相接连成一棵有根树，并满足任意同色边不相邻。问总方案数。答案模 $998244353$。

实验作屑题。~~本来是想先用多元拉反造个题然后找个高妙的组合解释，结果发现自己解释不了了~~

容易写出复合方程
$$
F_i=x_i\prod_{j\neq i}(1+F_j)
$$
所求即为
$$
[\mathbf x^{\mathbf n}]\prod_i(1+F_i)
$$
直接使用多元拉格朗日反演：
$$
[\mathbf x^{\mathbf n}]\prod_{i}(1+x_i)^{1+\sum_{j\neq i}n_j}\cdot\text{det}\left([i=j]-[i\neq j]\dfrac{x_j}{1+x_j}\right)
$$
关注行列式。设集合 $S$ 中的行没有选 $[i=j]$，那么现在考虑怎么把 $S$ 中的元素连成环。显然不管怎么连权值都一定是 $(-1)^*\sum_{i\in S}\dfrac{x_i}{1+x_i}$，只需要关注符号。实际上就是所有 $|S|$ 阶错排的符号之和，不难发现它就是 $(-1)^{|S|-1}(|S| - 1)$。由此，$n^2$ DP 就立即浮现了。

所以有人来用别的方法解释一下这个神秘的容斥系数吗……

```cpp
#include<bits/stdc++.h>
using namespace std;

const int p = 998244353, maxn = 5005;
struct Z {int x; Z(int x0 = 0) : x(x0) {}};
int inline check(int x) { return x >= p ? x - p : x; }
Z operator +(const Z a, const Z b) { return check(a.x + b.x); }
Z operator -(const Z a, const Z b) { return check(a.x - b.x + p); }
Z operator -(const Z a) {return check(p - a.x);}
Z operator *(const Z a, const Z b) { return 1LL * a.x * b.x % p; }
Z& operator +=(Z &a, const Z b) { return a = a + b; }
Z& operator -=(Z &a, const Z b) { return a = a - b; }
Z& operator *=(Z &a, const Z b) { return a = a * b; }
Z qpow(Z a, int k) {
	Z ans = 1;
	for (; k; a *= a, k >>= 1) if(k & 1) ans *= a;
	return ans;
}
Z fac[maxn], ifac[maxn], inv[maxn];
Z C_[maxn][maxn];
void init() {
	inv[1] = fac[0] = fac[1] = ifac[0] = ifac[1] = 1;
	for (int i = 2; i < maxn; i++)
		fac[i] = fac[i - 1] * i,
		inv[i] = -inv[p % i] * (p / i),
		ifac[i] = ifac[i - 1] * inv[i];
	for (int i = 0; i < maxn; i++)
	for (int j = 0; j <= i; j++)
		C_[i][j] = fac[i] * ifac[j] * ifac[i - j];
}
Z C(int n, int m) {
	if (n < 0 || m < 0 || n < m) return 0;
	return C_[n][m];
}

int m;
int n[maxn], sn;

int main() {
	init();
	scanf("%d", &m);
	for (int i = 1; i <= m; i++) scanf("%d", &n[i]), sn += n[i];
	Z ans = 0;
    Z f[maxn];
    memset(f, 0, sizeof(f));
    f[0] = 1;
    for (int j = 1; j <= m; j++)
    for (int k = j - 1; k >= 0; k--)
        f[k + 1] += f[k] * C(sn - n[j], n[j] - 1),
        f[k] *= C(sn - n[j] + 1, n[j]);
    for (int k = 0; k <= m; k++)
        ans += f[k] * (1 - k);
	printf("%d\n", ans);
}
```