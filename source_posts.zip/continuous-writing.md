---
title: "你要创作"杯接龙大战开幕
---

![](https://cdn.luogu.com.cn/upload/image_hosting/i11vane6.png)

经过紧张刺激的筹备，"你要创作"杯接龙大战已经正式开幕！

[宣传 PV](https://www.bilibili.com/video/BV1aW4y1V7vY/)

参与者名单、出场顺序和出场时间请在报名表或比赛镜像中查看。

[报名表（谷歌文档）](https://docs.google.com/document/d/18e7GXJf9X3vC1rZdDiomlmAMEMRILuFB65Ci96gXC7o)

[报名表（腾讯文档）](https://docs.qq.com/doc/DZGxzdFZLQnBDWlZR?&u=58c9719ce682494aa6e381d5504e977a)

[比赛的官方镜像（腾讯文档）](https://docs.qq.com/doc/DZHNCVUFETVl4VHRT?&u=58c9719ce682494aa6e381d5504e977a)